"""Shared deploy metadata computation functions.

Extracted from push.bzl and load.bzl so that image_manifest and image_index
can also compute deploy metadata when they have push_specs/load_specs attached.
"""

load("//img/private:layer_path_hints.bzl", "layer_hints_for_deploy_metadata")
load("//img/private:root_symlinks.bzl", "runfiles_slot")
load("//img/private:soci_deploy.bzl", "soci_deploy_children")
load("//img/private:stamp.bzl", "expand_or_write")
load("//img/private/common:build.bzl", "TOOLCHAIN")
load("//img/private/common:deploy_helpers.bzl", "add_build_time_push_outputs", "content_tracking_json_vars", "cross_mount_blob_repository")
load("//img/private/providers:deploy_info.bzl", "DeployInfo")
load("//img/private/providers:load_config_info.bzl", "LoadConfigInfo")
load("//img/private/providers:load_settings_info.bzl", "LoadSettingsInfo")
load("//img/private/providers:push_config_info.bzl", "PushConfigInfo")
load("//img/private/providers:push_settings_info.bzl", "PushSettingsInfo")

def _manifest_layer_sources(manifest_info):
    """Return the per-layer upstream sources of a manifest, aligned with its layers.

    Each element corresponds to a layer (in order) and is a list of
    {"registry": .., "repository": ..} dicts (empty for layers with no source).
    """
    return [
        [{"registry": source.registry, "repository": source.repository} for source in layer.sources]
        for layer in manifest_info.layers
    ]

def _write_layer_sources_file(ctx, *, manifest_info, index_info, output_prefix):
    """Write a JSON side file describing each layer's upstream sources.

    The file maps a manifest index (as a string) to a list aligned with that
    manifest's layers, each element being the list of sources for that layer. It is
    consumed by the deploy-metadata tool (`--layer-sources-file`) to populate the
    per-layer `sources` in the deploy manifest. Returns None (and writes nothing)
    when no layer records any source, so unaffected images stay byte-identical.
    """
    mapping = {}
    has_any = False
    if manifest_info != None:
        per_layer = _manifest_layer_sources(manifest_info)
        mapping["0"] = per_layer
        has_any = any([len(entry) > 0 for entry in per_layer])
    if index_info != None:
        for i, manifest in enumerate(index_info.manifests):
            per_layer = _manifest_layer_sources(manifest)
            mapping[str(i)] = per_layer
            if any([len(entry) > 0 for entry in per_layer]):
                has_any = True
    if not has_any:
        return None
    out = ctx.actions.declare_file(output_prefix + ".layer_sources.json")
    ctx.actions.write(out, json.encode(mapping))
    return out

def _add_manifest_compact_streams(manifest_index, manifest_info, args, inputs):
    """Record each compact-stream layer's .cstream for the deploy-metadata tool.

    For the "bes" strategy the layer's compressed blob is never materialized, so
    the syncer reconstructs it from the .cstream. We pass the .cstream so the tool
    can record its CAS digest, and add the .cstream plus the layer's
    content-addressed input files as action inputs so Bazel uploads them to the CAS
    the syncer reads from.
    """
    for layer_index, layer in enumerate(manifest_info.layers):
        if layer.compact_stream == None:
            continue
        args.add_all(
            "--layer-compact-stream",
            [layer.compact_stream],
            format_each = "{},{}=%s".format(manifest_index, layer_index),
        )
        inputs.append(layer.compact_stream)
        if layer.layer_input_files_cas != None:
            inputs.append(layer.layer_input_files_cas)

def _add_compact_stream_args(manifest_info, index_info, args, inputs):
    """Add --layer-compact-stream args for all compact-stream layers of the image."""
    if manifest_info != None:
        _add_manifest_compact_streams(0, manifest_info, args, inputs)
    if index_info != None:
        for i, manifest in enumerate(index_info.manifests):
            _add_manifest_compact_streams(i, manifest, args, inputs)

def compute_push_metadata(
        ctx,
        *,
        configuration_json,
        manifest_info,
        index_info,
        strategy,
        cross_mount_strategy,
        cross_mount_from,
        referrers,
        manifest_tags_expanded,
        pull_info,
        destination_file,
        output_prefix,
        signing = None,
        blob_repository = "",
        forbid_layer_push = False,
        deduplicated_push = "disabled",
        deduplicated_push_blob_repository = "",
        deduplicated_push_content = ""):
    """Compute push metadata for a deploy operation.

    Args:
        ctx: Rule context (for ctx.actions, ctx.toolchains, ctx.label).
        configuration_json: File with expanded registry/repository/tags JSON.
        manifest_info: ImageManifestInfo or None.
        index_info: ImageIndexInfo or None.
        strategy: Resolved push strategy string (never 'auto').
        cross_mount_strategy: Resolved cross-mount strategy string.
        cross_mount_from: DeployInfo for cross-mounting, or None.
        referrers: List of struct(manifest_info, index_info) for referrer pushes.
        manifest_tags_expanded: List of (child_index, File) tuples with already-expanded tag files.
        pull_info: PullInfo or None (for original registry/repository/tag/digest).
        destination_file: File containing {registry}/{repository}, or None.
        output_prefix: String prefix for declared output files.
        signing: struct(config_info, best_effort, targets) to enable signing of
            this push, or None.
        blob_repository: Staging repository for layer blobs, or "" (recorded in the
            deploy manifest so both push-at-build-time and `bazel run` honor it).
        forbid_layer_push: When True, records in the deploy manifest that layer
            blob uploads are forbidden (deploy may only cross-mount or skip
            already-present layers). Guards deploys of build-time-pushed blobs.
        deduplicated_push: Resolved deduplicated push mode ("disabled",
            "best_effort" or "enabled"). When not "disabled", records in the deploy
            manifest that `img deploy` should push in phases: check which manifests
            the registry already has, upload each still-missing blob once per
            registry, then cross-mount it into every destination repository.
        deduplicated_push_blob_repository: Repository that every blob the
            deduplicated push shares between repositories is uploaded to and
            cross-mounted from, or "" to let the deploy pick one per blob. Only
            recorded when deduplicated_push is active.
        deduplicated_push_content: What the deduplicated push writes to a blob's
            home repository ("blobs" or "blobs_and_artificial_manifests"). Only
            recorded when it is not the "blobs" default.

    Returns:
        Tuple of (metadata_file, layer_hints_file).
    """
    if manifest_info == None and index_info == None:
        fail("exactly one of manifest_info or index_info must be provided")
    if manifest_info != None and index_info != None:
        fail("exactly one of manifest_info or index_info must be provided, not both")

    inputs = [configuration_json]
    args = ctx.actions.args()
    push_metadata_args = [args]
    args.add("deploy-metadata")
    args.add("--command", "push")
    args.add("--strategy", strategy)
    args.add("--configuration-file", configuration_json)
    if blob_repository:
        args.add("--blob-repository", blob_repository)
    if forbid_layer_push:
        args.add("--forbid-layer-push")
    if deduplicated_push in ("best_effort", "enabled"):
        args.add("--deduplicated-push", deduplicated_push)

        # Both only mean anything to a deduplicating operation, so an operation that
        # opted out records neither.
        if deduplicated_push_blob_repository:
            args.add("--deduplicated-push-blob-repository", deduplicated_push_blob_repository)
        if deduplicated_push_content and deduplicated_push_content != "blobs":
            args.add("--deduplicated-push-content", deduplicated_push_content)

    if destination_file != None:
        inputs.append(destination_file)
        args.add("--destination-file", destination_file)

    if pull_info != None:
        if pull_info.registries:
            args.add_all(pull_info.registries, before_each = "--original-registry")
        if pull_info.repository:
            args.add("--original-repository", pull_info.repository)
        if pull_info.tag != None:
            args.add("--original-tag", pull_info.tag)
        if pull_info.digest != None:
            args.add("--original-digest", pull_info.digest)

    args.add("--cross-mount-strategy={}".format(cross_mount_strategy))

    if cross_mount_from != None:
        inputs.append(cross_mount_from.deploy_manifest)
        args.add("--cross-mount-from-manifest-path", cross_mount_from.deploy_manifest)

    args.add("--runfiles-slot", runfiles_slot(index_info, manifest_info))
    if manifest_info != None:
        args.add("--root-path", manifest_info.manifest)
        args.add("--root-kind", "manifest")
        args.add_all("--manifest-path", [manifest_info.manifest], format_each = "0=%s")
        inputs.append(manifest_info.manifest)

    if index_info != None:
        args.add("--root-path", index_info.index)
        args.add("--root-kind", "index")
        for i, manifest in enumerate(index_info.manifests):
            args.add_all("--manifest-path", [manifest.manifest], format_each = "{}=%s".format(i))
        for child_index, tag_file in manifest_tags_expanded:
            args.add_all("--manifest-tag-file", [tag_file], format_each = "{}=%s".format(child_index))
            inputs.append(tag_file)
        inputs.append(index_info.index)
        inputs.extend([manifest.manifest for manifest in index_info.manifests])

        # SOCI index pseudo-children are pushed as extra index children after the
        # real manifests. deploy-metadata parses each SOCI index manifest to derive
        # its config ("{}") and ztoc layer descriptors; the ztoc blobs are resolved
        # positionally from the matching manifest index in root symlinks.
        soci_children = soci_deploy_children(index_info.manifests)
        for offset, child in enumerate(soci_children):
            manifest_index = len(index_info.manifests) + offset
            args.add_all("--manifest-path", [child.manifest], format_each = "{}=%s".format(manifest_index))
            inputs.append(child.manifest)

    layer_sources_file = _write_layer_sources_file(
        ctx,
        manifest_info = manifest_info,
        index_info = index_info,
        output_prefix = output_prefix,
    )
    if layer_sources_file != None:
        inputs.append(layer_sources_file)
        args.add("--layer-sources-file", layer_sources_file)

    # For the bes strategy, compact-stream layers are reconstructed by the syncer
    # from the CAS, so record each .cstream and pull its input files into the CAS.
    if strategy == "bes":
        _add_compact_stream_args(manifest_info, index_info, args, inputs)

    for ref_idx, referrer in enumerate(referrers):
        ref_manifest_info = referrer.manifest_info
        ref_index_info = referrer.index_info
        args.add("--referrer-runfiles-slot", "{}={}".format(ref_idx, runfiles_slot(ref_index_info, ref_manifest_info)))
        if ref_manifest_info != None:
            args.add_all("--referrer-root-path", [ref_manifest_info.manifest], format_each = "{}=%s".format(ref_idx))
            args.add("--referrer-root-kind", "{}=manifest".format(ref_idx))
            args.add_all("--referrer-manifest-path", [ref_manifest_info.manifest], format_each = "{},0=%s".format(ref_idx))
            inputs.append(ref_manifest_info.manifest)
        elif ref_index_info != None:
            args.add_all("--referrer-root-path", [ref_index_info.index], format_each = "{}=%s".format(ref_idx))
            args.add("--referrer-root-kind", "{}=index".format(ref_idx))
            for i, manifest in enumerate(ref_index_info.manifests):
                args.add_all("--referrer-manifest-path", [manifest.manifest], format_each = "{},{}=%s".format(ref_idx, i))
            inputs.append(ref_index_info.index)
            inputs.extend([manifest.manifest for manifest in ref_index_info.manifests])

    # Signing: record the sign_setting config file's descriptor in the operation
    # so the deploy tool can match it against the sign_settings shipped in
    # runfiles. The config file itself is added to runfiles by the calling rule.
    if signing != None:
        inputs.append(signing.config_info.config_file)
        args.add("--sign-setting-file", signing.config_info.config_file)
        if signing.best_effort:
            args.add("--sign-best-effort")
        for target in signing.targets:
            args.add("--sign-target", target)

    outputs = []
    layer_hints_file = layer_hints_for_deploy_metadata(
        ctx,
        index_info = index_info,
        manifest_info = manifest_info,
        strategy = strategy,
        output_prefix = output_prefix,
        args = push_metadata_args,
        inputs = inputs,
        outputs = outputs,
    )
    metadata_out = ctx.actions.declare_file(output_prefix + ".json")
    output_args = ctx.actions.args()
    output_args.add(metadata_out)
    push_metadata_args.append(output_args)
    outputs.append(metadata_out)
    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    ctx.actions.run(
        inputs = inputs,
        outputs = outputs,
        executable = img_toolchain_info.tool_exe,
        arguments = push_metadata_args,
        mnemonic = "PushMetadata",
        execution_requirements = {"supports-path-mapping": "1"},
    )
    return metadata_out, layer_hints_file

def expand_manifest_tags_for_child(
        ctx,
        *,
        child_index,
        child_info,
        manifest_tags,
        build_settings_override,
        stamp_override,
        stamp_settings_override,
        output_prefix,
        extra_build_settings = None):
    """Expand manifest_tags templates for a single child manifest in an index.

    Args:
        ctx: Rule context.
        child_index: Index of the child manifest.
        child_info: ImageManifestInfo of the child manifest.
        manifest_tags: List of tag template strings.
        build_settings_override: Dict(string, string) of build settings.
        stamp_override: Stamp preference string.
        stamp_settings_override: StampSettingInfo provider.
        output_prefix: String prefix for output file names.
        extra_build_settings: Optional dict of additional template variables (merged with platform vars).

    Returns:
        Expanded tag File, or None if no expansion needed.
    """
    merged_extra = {}
    if extra_build_settings:
        merged_extra.update(extra_build_settings)
    merged_extra.update({
        "os": child_info.os or "",
        "architecture": child_info.architecture or "",
        "arch": child_info.architecture or "",
        "cpu": child_info.architecture or "",
        "variant": child_info.variant or "",
    })
    templates = dict(manifest_tags = manifest_tags)
    return expand_or_write(
        ctx = ctx,
        templates = templates,
        output_name = "{}.manifest_tags.{}.json".format(output_prefix, child_index),
        extra_build_settings = merged_extra,
        build_settings_override = build_settings_override,
        stamp_override = stamp_override,
        stamp_settings_override = stamp_settings_override,
    )

def merge_deploy_manifests(ctx, *, deploy_infos, push_strategy, load_strategy):
    """Merge multiple deploy manifests using the deploy-merge tool.

    Args:
        ctx: Rule context.
        deploy_infos: List of struct(metadata=File, layer_hints=File-or-None).
        push_strategy: Resolved push strategy for the merge ("eager", "lazy",
            "cas_registry" or "bes").
        load_strategy: Resolved load strategy for the merge ("eager" or "lazy").

    Returns:
        Tuple of (merged_metadata_file, merged_layer_hints_file).
    """
    inputs = []
    args = ctx.actions.args()
    args.add("deploy-merge")
    args.add("--push-strategy", push_strategy)
    args.add("--load-strategy", load_strategy)

    layer_hints_files = []
    for info in deploy_infos:
        inputs.append(info.metadata)
        if info.layer_hints != None:
            layer_hints_files.append(info.layer_hints)
            inputs.append(info.layer_hints)

    layer_hints_out = None
    if layer_hints_files:
        for f in layer_hints_files:
            args.add("--layer-hints-input", f)
        layer_hints_out = ctx.actions.declare_file(ctx.label.name + ".deploy_merged.layer_hints")
        args.add("--layer-hints-output", layer_hints_out)

    for info in deploy_infos:
        args.add(info.metadata)

    metadata_out = ctx.actions.declare_file(ctx.label.name + ".deploy_merged.json")
    args.add(metadata_out)

    outputs = [metadata_out]
    if layer_hints_out != None:
        outputs.append(layer_hints_out)

    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    ctx.actions.run(
        inputs = inputs,
        outputs = outputs,
        executable = img_toolchain_info.tool_exe,
        arguments = [args],
        mnemonic = "DeployMerge",
    )
    return metadata_out, layer_hints_out

def compute_load_metadata(
        ctx,
        *,
        configuration_json,
        manifest_info,
        index_info,
        strategy,
        pull_info,
        output_prefix):
    """Compute load metadata for a deploy operation.

    Args:
        ctx: Rule context (for ctx.actions, ctx.toolchains, ctx.label).
        configuration_json: File with expanded tags/daemon JSON.
        manifest_info: ImageManifestInfo or None.
        index_info: ImageIndexInfo or None.
        strategy: Resolved load strategy string (never 'auto').
        pull_info: PullInfo or None (for original registry/repository/tag/digest).
        output_prefix: String prefix for declared output files.

    Returns:
        Tuple of (metadata_file, layer_hints_file).
    """
    if manifest_info == None and index_info == None:
        fail("exactly one of manifest_info or index_info must be provided")
    if manifest_info != None and index_info != None:
        fail("exactly one of manifest_info or index_info must be provided, not both")

    inputs = [configuration_json]
    args = ctx.actions.args()
    load_metadata_args = [args]
    args.add("deploy-metadata")
    args.add("--command", "load")
    args.add("--strategy", strategy)
    args.add("--configuration-file", configuration_json)

    if pull_info != None:
        if pull_info.registries:
            args.add_all(pull_info.registries, before_each = "--original-registry")
        if pull_info.repository:
            args.add("--original-repository", pull_info.repository)
        if pull_info.tag != None:
            args.add("--original-tag", pull_info.tag)
        if pull_info.digest != None:
            args.add("--original-digest", pull_info.digest)

    args.add("--runfiles-slot", runfiles_slot(index_info, manifest_info))
    if manifest_info != None:
        args.add("--root-path", manifest_info.manifest)
        args.add("--root-kind", "manifest")
        args.add_all("--manifest-path", [manifest_info.manifest], format_each = "0=%s")
        inputs.append(manifest_info.manifest)

    if index_info != None:
        args.add("--root-path", index_info.index)
        args.add("--root-kind", "index")
        for i, manifest in enumerate(index_info.manifests):
            args.add_all("--manifest-path", [manifest.manifest], format_each = "{}=%s".format(i))
        inputs.append(index_info.index)
        inputs.extend([manifest.manifest for manifest in index_info.manifests])

    layer_sources_file = _write_layer_sources_file(
        ctx,
        manifest_info = manifest_info,
        index_info = index_info,
        output_prefix = output_prefix,
    )
    if layer_sources_file != None:
        inputs.append(layer_sources_file)
        args.add("--layer-sources-file", layer_sources_file)

    outputs = []
    layer_hints_file = layer_hints_for_deploy_metadata(
        ctx,
        index_info = index_info,
        manifest_info = manifest_info,
        strategy = strategy,
        output_prefix = output_prefix,
        args = load_metadata_args,
        inputs = inputs,
        outputs = outputs,
    )
    metadata_out = ctx.actions.declare_file(output_prefix + ".load.json")
    output_args = ctx.actions.args()
    output_args.add(metadata_out)
    load_metadata_args.append(output_args)
    outputs.append(metadata_out)
    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    ctx.actions.run(
        inputs = inputs,
        outputs = outputs,
        executable = img_toolchain_info.tool_exe,
        arguments = load_metadata_args,
        mnemonic = "LoadMetadata",
    )
    return metadata_out, layer_hints_file

def _registry_env(gateway, push_gateway, pull_gateway, insecure):
    """Build the registry-related action env dict, omitting empty entries.

    IMG_REGISTRY_GATEWAY is the shared fallback for both push and pull; the
    mode-specific vars take precedence (resolved by the img tool at runtime).
    IMG_INSECURE lets the actions talk to a plain-HTTP registry (or one with an
    untrusted certificate), like the img tool's global --insecure flag.
    """
    env = {}
    if gateway:
        env["IMG_REGISTRY_GATEWAY"] = gateway
    if push_gateway:
        env["IMG_REGISTRY_PUSH_GATEWAY"] = push_gateway
    if pull_gateway:
        env["IMG_REGISTRY_PULL_GATEWAY"] = pull_gateway
    if insecure:
        env["IMG_INSECURE"] = "1"
    return env

def build_time_push_actions(
        ctx,
        *,
        push_idx,
        configuration_json,
        manifest_info,
        index_info,
        sparse_layout,
        mode,
        content,
        blob_repository,
        manifest_repository,
        gateway,
        push_gateway,
        pull_gateway,
        insecure,
        pull_info,
        exec_requirements):
    """Create the PushImage actions for one push operation.

    Emits one action per blob (mnemonic PushImage) that pushes a single blob to
    the blob target repository (the staging repository if blob_repository is set,
    else the operation's own repository) and records where it landed in a JSON
    result: one action per layer, plus one per manifest for the config blob. The
    config actions run in all content modes, so after a build every blob of the
    image (layers and config) is present in the blob target repository. When
    content is not "blobs", also emits one action that pushes the config +
    manifest(s), depending on all per-layer results so it runs after them and
    mounts the layers from where they were pushed. That manifest push writes the
    tags only for content == "all"; "blobs_and_manifests" writes the manifest(s)
    by digest and leaves tagging to the `bazel run` deploy.

    Shared by the push_specs path (`process_deploy_specs`) and the standalone
    `image_push` rule so both push at build time identically.

    Args:
      ctx: the rule context.
      push_idx: integer index disambiguating declared output files when a target
        has more than one push operation; image_push always passes 0.
      configuration_json: File containing the img tool configuration (registry
        credentials, etc.).
      manifest_info: ManifestInfo for a single-manifest image, or None for an
        index image (in which case index_info must be set).
      index_info: ImageIndexInfo for a multi-manifest index image, or None when
        manifest_info is set.
      sparse_layout: sparse OCI layout File required when content is not
        "blobs"; None is accepted only for content == "blobs".
      mode: push mode string passed to the img tool (e.g. "push").
      content: one of "blobs" (push layer + config blobs only),
        "blobs_and_manifests" (push blobs then config+manifest(s) by digest, no
        tags) or "all" (same, plus the tags).
      blob_repository: optional staging repository to push blobs (layers and
        config) to before mounting them into the final repository; None means push
        directly.
      manifest_repository: optional repository to upload the manifest(s)/index and
        config to instead of the operation's own repository, used only when
        content is not "blobs". Layer blobs are still cross-mounted from
        blob_repository, so this does not change blob mounting.
      gateway: default registry gateway for both push and pull, or None.
      push_gateway: push-specific registry gateway override, or None.
      pull_gateway: pull-specific registry gateway override, or None.
      insecure: when True, the actions address registries over plain HTTP and
        accept untrusted TLS certificates (IMG_INSECURE).
      pull_info: PullInfo used when computing the manifest push metadata.
      exec_requirements: dict forwarded as the execution_requirements of every
        emitted PushImage action (e.g. {"requires-network": "1"}).

    Returns:
      List of Files that drive the emitted actions when built: the per-layer and
      per-config result JSONs, plus (when content is not "blobs") the single
      manifest marker file. Callers place them in the output group(s) selected by
      `add_build_time_push_outputs`.
    """
    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    tool = img_toolchain_info.tool_exe

    # Route registry requests through the configured gateway(s), if any, and pass
    # on insecure-registry access. These actions both push (upload) and pull
    # (shallow base layers), so all three gateway env vars are set; the img tool
    # resolves push/pull precedence at runtime.
    registry_env = _registry_env(gateway, push_gateway, pull_gateway, insecure)
    prefix = "{}.push_at_build_time.{}".format(ctx.label.name, push_idx)

    if manifest_info != None:
        manifests = [(0, manifest_info)]
    else:
        manifests = [(i, m) for i, m in enumerate(index_info.manifests)]

    # SOCI index pseudo-children are pushed as extra index children after the real
    # manifests (index case only; a bare manifest's SOCI index is annotation-only
    # and not pushed). Their manifest indices continue after the real manifests so
    # they line up with compute_push_metadata's deploy manifest.
    soci_children = []
    if index_info != None:
        soci_children = [
            (len(manifests) + offset, child)
            for offset, child in enumerate(soci_deploy_children(index_info.manifests))
        ]

    layer_results = []
    for (mi, manifest) in manifests:
        for (li, layer) in enumerate(manifest.layers):
            result = ctx.actions.declare_file("{}.blob.{}_{}.json".format(prefix, mi, li))
            args = ctx.actions.args()
            args.add("push")
            args.add("blob")
            args.add("--configuration-file", configuration_json)
            args.add("--metadata", layer.metadata)
            if blob_repository:
                args.add("--blob-repository", blob_repository)
            args.add("--mode", mode)
            args.add("--output", result)
            inputs = [configuration_json, layer.metadata]
            if layer.blob != None:
                args.add("--blob", layer.blob)
                inputs.append(layer.blob)
            elif layer.compact_stream != None and layer.layer_input_files_cas != None:
                args.add("--compact-stream", layer.compact_stream)
                args.add_all("--cas-dir", [layer.layer_input_files_cas], expand_directories = False)
                inputs.append(layer.compact_stream)
                inputs.append(layer.layer_input_files_cas)
            else:
                # Shallow layer: stream from its upstream source registries.
                for source in layer.sources:
                    args.add("--source", "{}/{}".format(source.registry, source.repository))
            blob_run_kwargs = dict(
                inputs = inputs,
                outputs = [result],
                executable = tool,
                arguments = [args],
                mnemonic = "PushImage",
                execution_requirements = exec_requirements,
                progress_message = "Pushing layer blob %s (manifest %d, layer %d)" % (ctx.label, mi, li),
            )
            if registry_env:
                blob_run_kwargs["env"] = registry_env
            ctx.actions.run(**blob_run_kwargs)
            layer_results.append(result)

    # Push each SOCI index's ztoc blobs. The SOCI index manifest carries the
    # authoritative ztoc descriptors, so `push blob` derives each descriptor by
    # hashing the ztoc (no per-ztoc metadata file needed); the manifest push then
    # cross-mounts them by digest from these recorded results.
    for (mi, child) in soci_children:
        for (li, ztoc_layer) in enumerate(child.layers):
            result = ctx.actions.declare_file("{}.blob.{}_{}.json".format(prefix, mi, li))
            ztoc_args = ctx.actions.args()
            ztoc_args.add("push")
            ztoc_args.add("blob")
            ztoc_args.add("--configuration-file", configuration_json)
            ztoc_args.add("--blob", ztoc_layer.blob)
            ztoc_args.add("--media-type", "application/octet-stream")
            if blob_repository:
                ztoc_args.add("--blob-repository", blob_repository)
            ztoc_args.add("--mode", mode)
            ztoc_args.add("--output", result)
            ztoc_run_kwargs = dict(
                inputs = [configuration_json, ztoc_layer.blob],
                outputs = [result],
                executable = tool,
                arguments = [ztoc_args],
                mnemonic = "PushImage",
                execution_requirements = exec_requirements,
                progress_message = "Pushing ztoc blob %s (soci manifest %d, layer %d)" % (ctx.label, mi, li),
            )
            if registry_env:
                ztoc_run_kwargs["env"] = registry_env
            ctx.actions.run(**ztoc_run_kwargs)
            layer_results.append(result)

    # Push each manifest's config blob to the same blob target as the layers (one
    # action per config). This runs in both content modes, so a "blobs"-mode build
    # leaves every blob of the image -- layers and config -- in the blob target
    # repository, and a later manifest push (here or via `bazel run`) only has to
    # write manifests. The config blob has no standalone descriptor file, so `push
    # blob` derives the descriptor by hashing the config file (which is exactly the
    # content the manifest's config descriptor addresses).
    config_results = []
    for (mi, manifest) in manifests + soci_children:
        config_result = ctx.actions.declare_file("{}.config.{}.json".format(prefix, mi))
        config_args = ctx.actions.args()
        config_args.add("push")
        config_args.add("blob")
        config_args.add("--configuration-file", configuration_json)
        config_args.add("--blob", manifest.config)
        if blob_repository:
            config_args.add("--blob-repository", blob_repository)
        config_args.add("--mode", mode)
        config_args.add("--output", config_result)
        config_run_kwargs = dict(
            inputs = [configuration_json, manifest.config],
            outputs = [config_result],
            executable = tool,
            arguments = [config_args],
            mnemonic = "PushImage",
            execution_requirements = exec_requirements,
            progress_message = "Pushing config blob %s (manifest %d)" % (ctx.label, mi),
        )
        if registry_env:
            config_run_kwargs["env"] = registry_env
        ctx.actions.run(**config_run_kwargs)
        config_results.append(config_result)

    if content == "blobs":
        return layer_results + config_results

    if sparse_layout == None:
        fail(("push_at_build_time with content='{}' needs the image's " +
              "sparse OCI layout to push the config and manifest(s), but the image referenced " +
              "by '{}' does not provide one (e.g. image_optimize output). Set " +
              "push_at_build_time_content=blobs, or reference a build-produced image.").format(content, ctx.label))

    # Push config + manifest(s) after all layers, mounting them from where the
    # per-layer actions put them. Use a dedicated eager, push-only deploy manifest
    # so the manifest push resolves blobs locally/by-mount and never stubs.
    deploy_metadata, _layer_hints = compute_push_metadata(
        ctx,
        configuration_json = configuration_json,
        manifest_info = manifest_info,
        index_info = index_info,
        strategy = "eager",
        cross_mount_strategy = "disabled",
        cross_mount_from = None,
        referrers = [],
        manifest_tags_expanded = [],
        pull_info = pull_info,
        destination_file = None,
        output_prefix = prefix,
        blob_repository = blob_repository,
    )
    marker = ctx.actions.declare_file("{}.pushed".format(prefix))
    args = ctx.actions.args()
    args.add("push")
    args.add("manifest")
    args.add("--request-file", deploy_metadata)
    args.add_all("--oci-layout", [sparse_layout], expand_directories = False)
    if manifest_repository:
        args.add("--manifest-repository", manifest_repository)

    # "blobs_and_manifests" publishes the manifest(s) by digest but leaves the
    # tags to the `bazel run` deploy, so a build never moves a tag; only "all"
    # writes them at build time.
    if content != "all":
        args.add("--skip-tags")
    args.add("--mode", mode)
    args.add("--marker", marker)
    args.add_all(layer_results, before_each = "--layer-result")
    manifest_run_kwargs = dict(
        inputs = [deploy_metadata, sparse_layout] + layer_results,
        outputs = [marker],
        executable = tool,
        arguments = [args],
        mnemonic = "PushImage",
        execution_requirements = exec_requirements,
        progress_message = "Pushing config and manifest(s) %s" % ctx.label,
    )
    if registry_env:
        manifest_run_kwargs["env"] = registry_env
    ctx.actions.run(**manifest_run_kwargs)
    return [marker] + config_results

def process_deploy_specs(
        ctx,
        *,
        manifest_info,
        index_info,
        manifest_infos,
        pull_info,
        push_specs,
        load_specs,
        allow_manifest_tags,
        sparse_layout = None):
    """Process push_specs and load_specs to produce a DeployInfo provider.

    Args:
        ctx: Rule context.
        manifest_info: ImageManifestInfo or None.
        index_info: ImageIndexInfo or None.
        manifest_infos: List of child ImageManifestInfo (for index manifest_tags expansion). Pass [] for manifest.
        pull_info: PullInfo or None.
        push_specs: List of targets providing PushConfigInfo.
        load_specs: List of targets providing LoadConfigInfo.
        allow_manifest_tags: If False, fail when a push spec has manifest_tags set.
        sparse_layout: The image's sparse OCI layout tree artifact (required when
            push_at_build_time is active; supplies manifest(s) + config to the push).

    Each push spec carries its own resolved push-at-build-time configuration
    (mode, content, blob/manifest repository, exec properties, gateways, output
    group) in its PushConfigInfo. When a spec's mode is not 'disabled', PushImage
    actions are emitted for it, and its blob staging repository is recorded in the
    deploy manifest for cross-mounting at `bazel run` time.

    Returns:
        Tuple of (DeployInfo or None, push_output_groups). push_output_groups is a
        (possibly empty) dict of output group name -> list of Files, holding the
        build-time push outputs (see `add_build_time_push_outputs`).
    """
    if not push_specs and not load_specs:
        return None, {}

    image_info = manifest_info if manifest_info != None else index_info
    image_target_vars = {
        "image_target_package": ctx.label.package,
        "image_target_name": ctx.label.name,
    }

    deploy_infos = []
    referrers = []
    sign_config_infos = []
    push_output_groups = {}

    for push_idx, deployment in enumerate(push_specs):
        push_config = deployment[PushConfigInfo]

        if not allow_manifest_tags and push_config.manifest_tags:
            fail("'manifest_tags' in push spec '{}' cannot be used with image_manifest (single-platform). Use image_index instead.".format(deployment.label))

        templates = dict(
            registry = push_config.registry,
            repository = push_config.repository,
            tags = push_config.tags,
        )
        newline_delimited_lists_files = None
        if push_config.tag_file:
            newline_delimited_lists_files = {"tags": push_config.tag_file}

        # When tracks_content is set, expose the image descriptor as a json-var so
        # the tag re-stamps when the digest changes and {{.digest}} is available.
        json_vars, json_path_to_root = content_tracking_json_vars(
            image_info.descriptor if push_config.tracks_content else None,
        )

        configuration_json = expand_or_write(
            ctx = ctx,
            templates = templates,
            output_name = "{}.push_deploy.{}.configuration.json".format(ctx.label.name, push_idx),
            newline_delimited_lists_files = newline_delimited_lists_files,
            build_settings_override = push_config.build_settings,
            stamp_override = push_config.stamp,
            stamp_settings_override = push_config.stamp_settings,
            extra_build_settings = image_target_vars,
            json_vars = json_vars,
            json_path_to_root = json_path_to_root,
        )

        manifest_tags_expanded = []
        if push_config.manifest_tags:
            for i, manifest in enumerate(manifest_infos):
                tag_file = expand_manifest_tags_for_child(
                    ctx,
                    child_index = i,
                    child_info = manifest,
                    manifest_tags = push_config.manifest_tags,
                    build_settings_override = push_config.build_settings,
                    stamp_override = push_config.stamp,
                    stamp_settings_override = push_config.stamp_settings,
                    output_prefix = "{}.push_deploy.{}".format(ctx.label.name, push_idx),
                    extra_build_settings = image_target_vars,
                )
                if tag_file != None:
                    manifest_tags_expanded.append((i, tag_file))

        deploy_metadata, layer_hints = compute_push_metadata(
            ctx,
            configuration_json = configuration_json,
            manifest_info = manifest_info,
            index_info = index_info,
            strategy = push_config.strategy,
            cross_mount_strategy = push_config.cross_mount_strategy,
            cross_mount_from = push_config.cross_mount_from,
            referrers = push_config.referrers,
            manifest_tags_expanded = manifest_tags_expanded,
            pull_info = pull_info,
            destination_file = push_config.destination_file,
            output_prefix = "{}.push_deploy.{}".format(ctx.label.name, push_idx),
            signing = push_config.signing,
            # Only record the staging repository for cross-mounting when this spec
            # actually pushes at build time; otherwise a deploy would try to mount
            # from a repository nothing was staged to.
            blob_repository = cross_mount_blob_repository(push_config.push_at_build_time_mode, push_config.blob_repository),
            forbid_layer_push = push_config.forbid_layer_push,
            deduplicated_push = push_config.deduplicated_push,
            deduplicated_push_blob_repository = push_config.deduplicated_push_blob_repository,
            deduplicated_push_content = push_config.deduplicated_push_content,
        )
        deploy_infos.append(struct(metadata = deploy_metadata, layer_hints = layer_hints))
        referrers.extend(push_config.referrers)
        if push_config.signing != None:
            sign_config_infos.append(push_config.signing.config_info)

        # Push at build time via PushImage actions, per push spec.
        if push_config.push_at_build_time_mode in ("best_effort", "enabled"):
            add_build_time_push_outputs(
                push_output_groups,
                build_time_push_actions(
                    ctx,
                    push_idx = push_idx,
                    configuration_json = configuration_json,
                    manifest_info = manifest_info,
                    index_info = index_info,
                    sparse_layout = sparse_layout,
                    mode = push_config.push_at_build_time_mode,
                    content = push_config.push_at_build_time_content,
                    blob_repository = push_config.blob_repository,
                    manifest_repository = push_config.push_at_build_time_manifest_repository,
                    gateway = push_config.push_at_build_time_gateway,
                    push_gateway = push_config.push_at_build_time_push_gateway,
                    pull_gateway = push_config.push_at_build_time_pull_gateway,
                    insecure = push_config.insecure,
                    pull_info = pull_info,
                    exec_requirements = push_config.push_at_build_time_exec_properties,
                ),
                push_config.push_at_build_time_output_group,
            )

    for load_idx, deployment in enumerate(load_specs):
        load_config = deployment[LoadConfigInfo]

        templates = dict(
            registry = load_config.registry,
            repository = load_config.repository,
            tags = load_config.tags,
            daemon = load_config.daemon,
        )
        newline_delimited_lists_files = None
        if load_config.tag_file:
            newline_delimited_lists_files = {"tags": load_config.tag_file}

        # When tracks_content is set, expose the image descriptor as a json-var so
        # the tag re-stamps when the digest changes and {{.digest}} is available.
        json_vars, json_path_to_root = content_tracking_json_vars(
            image_info.descriptor if load_config.tracks_content else None,
        )

        configuration_json = expand_or_write(
            ctx = ctx,
            templates = templates,
            output_name = "{}.load_deploy.{}.configuration.json".format(ctx.label.name, load_idx),
            newline_delimited_lists_files = newline_delimited_lists_files,
            build_settings_override = load_config.build_settings,
            stamp_override = load_config.stamp,
            stamp_settings_override = load_config.stamp_settings,
            extra_build_settings = image_target_vars,
            json_vars = json_vars,
            json_path_to_root = json_path_to_root,
        )

        deploy_metadata, layer_hints = compute_load_metadata(
            ctx,
            configuration_json = configuration_json,
            manifest_info = manifest_info,
            index_info = index_info,
            strategy = load_config.strategy,
            pull_info = pull_info,
            output_prefix = "{}.load_deploy.{}".format(ctx.label.name, load_idx),
        )
        deploy_infos.append(struct(metadata = deploy_metadata, layer_hints = layer_hints))

    include_layers = (
        any([d[PushConfigInfo].strategy == "eager" for d in push_specs]) or
        any([d[LoadConfigInfo].strategy == "eager" for d in load_specs])
    )

    if len(deploy_infos) == 1:
        return DeployInfo(
            image = image_info,
            deploy_manifest = deploy_infos[0].metadata,
            layer_hints = deploy_infos[0].layer_hints,
            include_layers = include_layers,
            sign_settings = sign_config_infos,
            referrers = referrers,
        ), push_output_groups

    first_push_strategy = push_specs[0][PushConfigInfo].strategy if push_specs else ctx.attr._push_settings[PushSettingsInfo].strategy
    first_load_strategy = load_specs[0][LoadConfigInfo].strategy if load_specs else ctx.attr._load_settings[LoadSettingsInfo].strategy

    merged_metadata, merged_layer_hints = merge_deploy_manifests(
        ctx,
        deploy_infos = deploy_infos,
        push_strategy = first_push_strategy,
        load_strategy = first_load_strategy,
    )
    return DeployInfo(
        image = image_info,
        deploy_manifest = merged_metadata,
        layer_hints = merged_layer_hints,
        include_layers = include_layers,
        sign_settings = sign_config_infos,
        referrers = referrers,
    ), push_output_groups
