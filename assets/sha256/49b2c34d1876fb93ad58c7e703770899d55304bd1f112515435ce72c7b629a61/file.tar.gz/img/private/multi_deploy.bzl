"""Multi deploy rule for deploying multiple operations as a unified command."""

load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("@hermetic_launcher//launcher:lib.bzl", "launcher")
load("//img/private:root_symlinks.bzl", "calculate_root_symlinks", "symlink_name_prefix")
load("//img/private:sign_settings.bzl", "add_sign_setting_symlinks")
load("//img/private/common:build.bzl", "TOOLCHAIN", "TOOLCHAINS")
load("//img/private/common:default_deploy_tool.bzl", "default_deploy_tool")
load("//img/private/common:transitions.bzl", "reset_platform_transition")
load("//img/private/providers:deploy_info.bzl", "DeployInfo")
load("//img/private/providers:deploy_tool_info.bzl", "DeployToolInfo")
load("//img/private/providers:index_info.bzl", "ImageIndexInfo")
load("//img/private/providers:load_settings_info.bzl", "LoadSettingsInfo")
load("//img/private/providers:manifest_info.bzl", "ImageManifestInfo")
load("//img/private/providers:multiple_deploy_info.bzl", "MultipleDeployInfo")
load("//img/private/providers:push_settings_info.bzl", "PushSettingsInfo")
load("//img/private/providers:stamp_setting_info.bzl", "StampSettingInfo")

def _multi_deploy_strategy(ctx, operation_type):
    """Determine the strategy to use based on the settings and operation type."""
    if operation_type == "push":
        push_settings = ctx.attr._push_settings[PushSettingsInfo]
        strategy = ctx.attr.push_strategy
        if strategy == "auto":
            strategy = push_settings.strategy
        return strategy
    elif operation_type == "load":
        load_settings = ctx.attr._load_settings[LoadSettingsInfo]
        strategy = ctx.attr.load_strategy
        if strategy == "auto":
            strategy = load_settings.strategy
        return strategy
    else:
        fail("Unknown operation type: {}".format(operation_type))

def _collect_deploy_infos(ctx):
    """Flatten all operations into a list of DeployInfo.

    A target providing DeployInfo contributes itself; a target providing
    MultipleDeployInfo contributes each of its infos.

    MultipleDeployInfo is deliberately allowed to add 0 operations.
    """
    deploy_infos = []
    for operation in ctx.attr.operations:
        if DeployInfo in operation:
            deploy_infos.append(operation[DeployInfo])
        elif MultipleDeployInfo in operation:
            infos = getattr(operation[MultipleDeployInfo], "infos", None)
            if infos != None:
                deploy_infos.extend(infos.to_list())
        elif ImageManifestInfo in operation or ImageIndexInfo in operation:
            fail("Target '{}' provides an image but not DeployInfo. Add 'push_specs' or 'load_specs' to produce DeployInfo, or wrap it with image_push.".format(operation.label))
        else:
            fail("Target '{}' does not provide DeployInfo or MultipleDeployInfo.".format(operation.label))
    return deploy_infos

def _compute_multi_deploy_metadata(*, ctx, deploy_infos):
    """Compute the merged deploy metadata from all operations."""
    inputs = []
    deploy_manifests = []
    layer_hints_files = []

    # Collect all deploy manifests and layer hints from operations
    for deploy_info in deploy_infos:
        deploy_manifests.append(deploy_info.deploy_manifest)
        inputs.append(deploy_info.deploy_manifest)
        if deploy_info.layer_hints != None:
            layer_hints_files.append(deploy_info.layer_hints)
            inputs.append(deploy_info.layer_hints)

    # Create the merge command
    merge_args = ctx.actions.args()
    merge_args.add("--push-strategy", _multi_deploy_strategy(ctx, "push"))
    merge_args.add("--load-strategy", _multi_deploy_strategy(ctx, "load"))

    # Filter the assembled operations by kind. push_specs contribute push (and
    # their associated registry_tag) operations; load_specs contribute load
    # operations. Only the requested kinds are merged into the final manifest.
    merge_args.add_all(ctx.attr.deploy_operations, before_each = "--operation")

    # Add layer hints inputs and output if any exist
    layer_hints_out = None
    if layer_hints_files:
        merge_args.add_all(layer_hints_files, before_each = "--layer-hints-input")
        layer_hints_out = ctx.actions.declare_file(ctx.label.name + ".layer_hints")
        merge_args.add("--layer-hints-output", layer_hints_out)

    # Add input deploy manifest files
    merge_args.add_all(deploy_manifests)

    # Output file
    metadata_out = ctx.actions.declare_file(ctx.label.name + ".json")
    merge_args.add(metadata_out)
    merge_args.set_param_file_format("multiline")
    merge_args.use_param_file("@%s", use_always = True)

    outputs = [metadata_out]
    if layer_hints_out != None:
        outputs.append(layer_hints_out)

    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    ctx.actions.run(
        inputs = inputs,
        outputs = outputs,
        executable = img_toolchain_info.tool_exe,
        arguments = ["deploy-merge", merge_args],
        mnemonic = "MultiDeployMerge",
    )
    return metadata_out, layer_hints_out

def _split_image(image):
    """Split an image provider into (index_info, manifest_info); exactly one is non-None."""
    if hasattr(image, "manifests"):
        return image, None
    return None, image

def _collect_operation_root_symlinks(deploy_infos, *, symlink_name_prefix):
    """Build the runfiles symlink tree for all operations.

    Every deploy operation names the runfiles slot holding its image (see
    `runfiles_slot`), so each image and referrer is laid out once, however many
    operations of the merged deploy manifest deploy it.
    """
    root_symlinks = {}
    for deploy_info in deploy_infos:
        index_info, manifest_info = _split_image(deploy_info.image)
        root_symlinks.update(calculate_root_symlinks(
            index_info = index_info,
            manifest_info = manifest_info,
            include_layers = deploy_info.include_layers,
            symlink_name_prefix = symlink_name_prefix,
        ))
        for referrer in getattr(deploy_info, "referrers", []):
            root_symlinks.update(calculate_root_symlinks(
                index_info = referrer.index_info,
                manifest_info = referrer.manifest_info,
                include_layers = deploy_info.include_layers,
                symlink_name_prefix = symlink_name_prefix,
            ))
    return root_symlinks

def _multi_deploy_impl(ctx):
    """Implementation of the multi_deploy rule."""
    if not ctx.attr.operations:
        fail("operations attribute cannot be empty")

    if not ctx.attr.deploy_operations:
        fail("deploy_operations attribute cannot be empty; specify [\"push\"], [\"load\"], or [\"push\", \"load\"]")
    for operation in ctx.attr.deploy_operations:
        if operation not in ("push", "load"):
            fail("deploy_operations may only contain \"push\" and/or \"load\", got \"{}\"".format(operation))

    deploy_infos = _collect_deploy_infos(ctx)

    # Merge all deploy manifests
    deploy_metadata, layer_hints = _compute_multi_deploy_metadata(ctx = ctx, deploy_infos = deploy_infos)

    # Create the executable
    root_symlinks_prefix = symlink_name_prefix(ctx)
    deployer = ctx.actions.declare_file(ctx.label.name + ".exe")
    deploy_tool_info = ctx.attr.deploy_tool[DeployToolInfo] if ctx.attr.deploy_tool != None else ctx.attr._deploy_tool[DeployToolInfo]
    embedded_args, transformed_args = launcher.args_from_entrypoint(executable_file = deploy_tool_info.img_deploy_exe)
    embedded_args.extend(["deploy", "--runfiles-root-symlinks-prefix", root_symlinks_prefix])

    # Every operation expanded to an empty MultipleDeployInfo, so the merged
    # manifest is empty on purpose.
    if not deploy_infos:
        embedded_args.append("--allow-empty")
    embedded_args.append("--request-file")
    embedded_args, transformed_args = launcher.append_runfile(
        file = deploy_metadata,
        embedded_args = embedded_args,
        transformed_args = transformed_args,
    )
    launcher.compile_stub(
        ctx = ctx,
        embedded_args = embedded_args,
        transformed_args = transformed_args,
        output_file = deployer,
        template_file = deploy_tool_info.launcher_template,
    )

    # Collect all image providers for root symlinks
    root_symlinks = _collect_operation_root_symlinks(deploy_infos, symlink_name_prefix = root_symlinks_prefix)

    # Add merged layer hints to root symlinks if present
    if layer_hints != None:
        root_symlinks["{}layer_hints".format(root_symlinks_prefix)] = layer_hints

    # Collect sign_setting config files from all operations and ship them (plus
    # their signer plugins) into the deployer's runfiles.
    sign_config_infos = []
    for deploy_info in deploy_infos:
        if hasattr(deploy_info, "sign_settings"):
            sign_config_infos.extend(deploy_info.sign_settings)
    plugin_runfiles = add_sign_setting_symlinks(root_symlinks, sign_config_infos)

    # Merge environment settings from push and load
    environment = {}
    inherited_environment = ["DOCKER_CONFIG", "IMG_AUTH_DEBUG"]

    push_settings = ctx.attr._push_settings[PushSettingsInfo]
    load_settings = ctx.attr._load_settings[LoadSettingsInfo]

    if push_settings.remote_cache or load_settings.remote_cache:
        environment["IMG_REAPI_ENDPOINT"] = push_settings.remote_cache or load_settings.remote_cache
        inherited_environment.append("IMG_REAPI_ENDPOINT")

    if push_settings.remote_instance_name or load_settings.remote_instance_name:
        environment["IMG_REAPI_INSTANCE_NAME"] = push_settings.remote_instance_name or load_settings.remote_instance_name
        inherited_environment.append("IMG_REAPI_INSTANCE_NAME")

    if push_settings.credential_helper or load_settings.credential_helper:
        environment["IMG_CREDENTIAL_HELPER"] = push_settings.credential_helper or load_settings.credential_helper
        inherited_environment.append("IMG_CREDENTIAL_HELPER")

    if push_settings.credential_helper_oci_registry or load_settings.credential_helper_oci_registry:
        environment["IMG_CREDENTIAL_HELPER_OCI_REGISTRY"] = push_settings.credential_helper_oci_registry or load_settings.credential_helper_oci_registry
        inherited_environment.append("IMG_CREDENTIAL_HELPER_OCI_REGISTRY")

    if push_settings.credential_helper_remote_cache or load_settings.credential_helper_remote_cache:
        environment["IMG_CREDENTIAL_HELPER_REMOTE_CACHE"] = push_settings.credential_helper_remote_cache or load_settings.credential_helper_remote_cache
        inherited_environment.append("IMG_CREDENTIAL_HELPER_REMOTE_CACHE")

    # Insecure registry access (plain HTTP, untrusted certificates). Always
    # inherited, so IMG_INSECURE from the environment works when the flag is off;
    # only set when the flag asks for it.
    inherited_environment.append("IMG_INSECURE")
    if push_settings.insecure or load_settings.insecure:
        environment["IMG_INSECURE"] = "1"

    # Add REGISTRY_AUTH_FILE if docker_config_path is set
    docker_config_path = ctx.attr._docker_config_path[BuildSettingInfo].value
    if docker_config_path:
        environment["REGISTRY_AUTH_FILE"] = docker_config_path

    return [
        DefaultInfo(
            files = depset([deployer]),
            executable = deployer,
            runfiles = ctx.runfiles(
                files = [
                    deploy_tool_info.img_deploy_exe,
                    deploy_metadata,
                ],
                root_symlinks = root_symlinks,
            ).merge_all(plugin_runfiles),
        ),
        OutputGroupInfo(
            deploy_manifest = depset([deploy_metadata]),
        ),
        RunEnvironmentInfo(
            environment = environment,
            inherited_environment = inherited_environment,
        ),
    ]

multi_deploy = rule(
    implementation = _multi_deploy_impl,
    doc = """Deploys multiple container images in a single coordinated command.

Use `push_specs` and `load_specs` on your image targets to attach deployment
configuration directly, then reference the images in `operations`:

```python
load("@rules_img//img:image.bzl", "image_manifest")
load("@rules_img//img:push.bzl", "image_push_spec")
load("@rules_img//img:multi_deploy.bzl", "multi_deploy")

image_push_spec(
    name = "push_spec",
    registry = "gcr.io",
    repository = "my-project/{{.image_target_name}}",
    tag = "latest",
)

image_manifest(
    name = "frontend",
    base = "@distroless_cc",
    layers = [":frontend_layer"],
    push_specs = [":push_spec"],
)

image_manifest(
    name = "backend",
    base = "@distroless_cc",
    layers = [":backend_layer"],
    push_specs = [":push_spec"],
)

multi_deploy(
    name = "deploy_all",
    operations = [
        ":frontend",
        ":backend",
    ],
)
```

Alternatively, standalone `image_push` or `image_load` targets that already
provide `DeployInfo` can be used directly in `operations`, as can custom
targets that provide `MultipleDeployInfo` to contribute several deploy
operations at once.

`multi_deploy` has no push at build time of its own; it deploys at `bazel run`
time. When `push_at_build_time` is enabled, the `image_push` targets (or images
with `push_specs`) referenced here already push at build time on their own —
`multi_deploy` does not push them a second time.

Runtime usage:
```bash
bazel run //path/to:deploy_all
```
""",
    attrs = {
        "operations": attr.label_list(
            doc = """List of operations to deploy together.

Each operation must provide DeployInfo (typically from image_push, image_load,
image_manifest with push_specs/load_specs, or image_index with push_specs/load_specs)
or MultipleDeployInfo (whose `infos` are expanded in place).
All operations will be merged and executed in the order specified.

A MultipleDeployInfo with no `infos` is allowed and results in a no-op instead of an error.
""",
            mandatory = True,
            # OR-semantics: accepts image targets without DeployInfo so that
            # _multi_deploy_impl can provide actionable error messages guiding
            # users to add push_specs/load_specs or wrap with image_push.
            providers = [[DeployInfo], [MultipleDeployInfo], [ImageManifestInfo], [ImageIndexInfo]],
        ),
        "push_strategy": attr.string(
            doc = """Push strategy to use for all push operations in the deployment.

See [push strategies documentation](/docs/push-strategies.md) for detailed information.
""",
            default = "auto",
            values = ["auto", "eager", "lazy", "cas_registry", "bes"],
        ),
        "load_strategy": attr.string(
            doc = """Load strategy to use for all load operations in the deployment.

Available strategies:
- **`auto`** (default): Uses the global default load strategy
- **`eager`**: Downloads all layers during the build phase
- **`lazy`**: Downloads layers only when needed during the load operation
""",
            default = "auto",
            values = ["auto", "eager", "lazy"],
        ),
        "deploy_operations": attr.string_list(
            doc = """Which kinds of deploy operations to perform.

Acts as a filter when assembling the final deploy manifest from all `operations`:

- `"push"`: include push operations (and their associated registry tag operations).
- `"load"`: include load operations.

Defaults to `["push", "load"]`, performing every operation contributed by the
`operations` targets. Narrow it when your images carry both `push_specs` and
`load_specs` but a particular deployment should only push or only load -- for
example, `["push"]` to push without loading, or `["load"]` to load without pushing.
""",
            default = ["push", "load"],
        ),
        "_push_settings": attr.label(
            default = Label("//img/private/settings:push"),
            providers = [PushSettingsInfo],
        ),
        "_load_settings": attr.label(
            default = Label("//img/private/settings:load"),
            providers = [LoadSettingsInfo],
        ),
        "_stamp_settings": attr.label(
            default = Label("//img/private/settings:stamp"),
            providers = [StampSettingInfo],
        ),
        "_docker_config_path": attr.label(
            default = Label("//img/settings:docker_config_path"),
            providers = [BuildSettingInfo],
        ),
        "tool_cfg": attr.string(
            doc = """Configuration of the deployer executable platform.

Available options:
- **`host`** (default): Deployer executable matches the host platform.
- **`target`**: Deployer executable matches the target platform(s) specified via `--platforms`.
""",
            default = "host",
            values = ["host", "target"],
        ),
        "deploy_tool": attr.label(
            doc = """Optional label of a deploy tool target providing `DeployToolInfo` (created with `img_deploy_tool` from `@rules_img//img:deploy_tool.bzl`). When set, overrides `tool_cfg`.""",
            providers = [DeployToolInfo],
        ),
        "_deploy_tool": attr.label(
            default = default_deploy_tool,
            providers = [DeployToolInfo],
        ),
    },
    executable = True,
    cfg = reset_platform_transition,
    toolchains = [
        launcher.finalizer_toolchain_type,
    ] + TOOLCHAINS,
)
