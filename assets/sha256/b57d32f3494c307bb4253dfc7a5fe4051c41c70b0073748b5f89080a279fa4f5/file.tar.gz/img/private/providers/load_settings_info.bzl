"""Provider for load settings."""

DOC = """\
Collection of active load settings.
"""

FIELDS = dict(
    strategy = "The default load strategy to use",
    daemon = "The daemon to target by default",
    remote_cache = "Bazel remote cache to use for the push rule as part of the lazy push strategy. Uses the same format as Bazel's --remote_cache flag. Uses $IMG_REAPI_ENDPOINT env var if not set.",
    remote_instance_name = "Remote instance name for REAPI CAS requests. Set as instance_name field in CAS RPCs and as path prefix in ByteStream resource names. Uses $IMG_REAPI_INSTANCE_NAME env var if not set.",
    credential_helper = "Credential helper to use for registry requests and load-strategy gRPC connections. See docs/credential-helpers.md for details. Uses $IMG_CREDENTIAL_HELPER env var or tools/credential-helper if not set.",
    credential_helper_oci_registry = "Credential helper used only for OCI registry operations. Takes precedence over credential_helper for registry auth. Uses $IMG_CREDENTIAL_HELPER_OCI_REGISTRY env var if not set. See docs/credential-helpers.md.",
    credential_helper_remote_cache = "Credential helper used only to authenticate gRPC calls to the remote cache / remote execution API. Takes precedence over credential_helper for those calls. Uses $IMG_CREDENTIAL_HELPER_REMOTE_CACHE env var if not set. See docs/credential-helpers.md.",
    insecure = "Bool: when True, registries are addressed over plain HTTP and untrusted TLS certificates are accepted (like crane's --insecure). Maps to the IMG_INSECURE env var of the img tool.",
    validate_cas_blobs = "Bool: when True, each deploy operation that reads its blobs from Bazel's cache (every push strategy but 'eager', and the lazy load strategy) gets a validation action taking all of its layer blobs as action inputs, so the cache keeps them. See docs/push-strategies.md#remote-cache-eviction.",
)

LoadSettingsInfo = provider(
    doc = DOC,
    fields = FIELDS,
)
