"""Image index rule for composing multi-layer OCI images."""

load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("//img/private:oci_layout_action.bzl", "run_oci_layout_action")
load("//img/private:push_metadata.bzl", "process_deploy_specs")
load("//img/private:soci_deploy.bzl", "soci_deploy_children")
load("//img/private:stamp.bzl", "expand_or_write")
load("//img/private/common:build.bzl", "TOOLCHAIN", "TOOLCHAINS")
load("//img/private/common:layout_blob.bzl", "blob_for_layout")
load("//img/private/common:transitions.bzl", "multi_platform_image_transition", "reset_platform_transition")
load("//img/private/common:write_index_json.bzl", "write_index_json")
load("//img/private/providers:index_info.bzl", "ImageIndexInfo")
load("//img/private/providers:load_config_info.bzl", "LoadConfigInfo")
load("//img/private/providers:load_settings_info.bzl", "LoadSettingsInfo")
load("//img/private/providers:manifest_info.bzl", "ImageManifestInfo")
load("//img/private/providers:oci_layout_settings_info.bzl", "OCILayoutSettingsInfo")
load("//img/private/providers:pull_info.bzl", "PullInfo")
load("//img/private/providers:push_config_info.bzl", "PushConfigInfo")
load("//img/private/providers:push_settings_info.bzl", "PushSettingsInfo")
load("//img/private/providers:stamp_setting_info.bzl", "StampSettingInfo")

def _build_oci_layout(ctx, format, index_out, manifests):
    """Build the OCI layout for a multi-platform image.

    Args:
        ctx: Rule context.
        format: The output format, either "directory" or "tar".
        index_out: The index file.
        manifests: List of ImageManifestInfo providers.

    Returns:
        The OCI layout directory (tree artifact).
    """
    if format not in ["directory", "tar"]:
        fail('oci layout format must be either "directory" or "tar"')
    oci_layout_output = None
    if format == "directory":
        oci_layout_output = ctx.actions.declare_directory(ctx.label.name + "_oci_layout")
    else:
        oci_layout_output = ctx.actions.declare_file(ctx.label.name + "_oci_layout.tar")

    args = ctx.actions.args()
    args.add("oci-layout")
    args.add("--format", format)
    args.add("--index", index_out.path)
    if ctx.attr._oci_layout_settings[OCILayoutSettingsInfo].allow_shallow_oci_layout:
        args.add("--allow-missing-blobs")

    inputs = [index_out]

    # Add manifest and config files for each platform
    for manifest in manifests:
        args.add("--manifest-path", manifest.manifest.path)
        args.add("--config-path", manifest.config.path)
        inputs.append(manifest.manifest)
        inputs.append(manifest.config)

        # Add layers with metadata=blob mapping
        for layer in manifest.layers:
            blob = blob_for_layout(ctx, layer, format)
            if blob != None:
                args.add("--layer", "{}={}".format(layer.metadata.path, blob.path))
                inputs.append(layer.metadata)
                inputs.append(blob)

    run_oci_layout_action(
        ctx,
        format = format,
        output = oci_layout_output,
        args = args,
        inputs = inputs,
        mnemonic = "OCIIndexLayout",
    )

    return oci_layout_output

def _build_sparse_oci_layout(ctx, format, index_out, manifests):
    """Build a sparse OCI layout for a multi-platform image (without layer blobs).

    Args:
        ctx: Rule context.
        format: The output format, either "directory" or "tar".
        index_out: The index file.
        manifests: List of ImageManifestInfo providers.

    Returns:
        The sparse OCI layout output (tree artifact or tar file).
    """
    if format not in ["directory", "tar"]:
        fail('sparse oci layout format must be either "directory" or "tar"')
    if format == "directory":
        output = ctx.actions.declare_directory(ctx.label.name + "_sparse_oci_layout")
    else:
        output = ctx.actions.declare_file(ctx.label.name + "_sparse_oci_layout.tar")

    args = ctx.actions.args()
    args.add("sparse-oci-layout")
    args.add("--format", format)
    args.add("--index", index_out.path)
    args.add("--output", output.path)

    inputs = [index_out]

    for manifest in manifests:
        args.add("--manifest-path", manifest.manifest.path)
        args.add("--config-path", manifest.config.path)
        inputs.append(manifest.manifest)
        inputs.append(manifest.config)

        for layer in manifest.layers:
            args.add("--layer", layer.metadata.path)
            inputs.append(layer.metadata)
            if layer.compact_stream != None:
                args.add("--layer-compact-stream", "{}={}".format(layer.metadata.path, layer.compact_stream.path))
                inputs.append(layer.compact_stream)

    # Include each SOCI index (an extra child of the OCI index) so its manifest
    # and "{}" config blobs are resolvable by digest at push time. Its ztoc layer
    # blobs are not embedded in the sparse layout (they are shipped as positional
    # layer runfiles); the SOCI manifest already carries their descriptors.
    for child in soci_deploy_children(manifests):
        args.add("--manifest-path", child.manifest.path)
        args.add("--config-path", child.config.path)
        inputs.append(child.manifest)
        inputs.append(child.config)

    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    if format == "directory" and img_toolchain_info.use_treeartifact_uplevel_symlinks:
        args.add("--symlink")
    ctx.actions.run(
        inputs = inputs,
        outputs = [output],
        executable = img_toolchain_info.tool_exe,
        arguments = [args],
        mnemonic = "SparseOCIIndexLayout",
    )

    return output

def _get_manifests(ctx):
    if len(ctx.attr.platforms) == 0:
        return ctx.attr.manifests
    manifests = []
    for i in range(len(ctx.attr.platforms)):
        manifests.extend(ctx.split_attr.manifests[str(i)])
    return manifests

def _image_index_impl(ctx):
    manifests = _get_manifests(ctx)
    manifest_infos = [manifest[ImageManifestInfo] for manifest in manifests]

    # Pick a representative PullInfo (base image identity) for index annotations and
    # as an image-level source for cross-mounting. Per-layer sources
    # (SingleLayerInfo.sources) now carry each layer's own upstream origin, so
    # manifests based on different external images -- different registries or
    # repositories, possibly shallow -- can be combined freely. We therefore no
    # longer require a single PullInfo to cover every missing blob, and no longer
    # fail when the manifests' base images disagree. Only image_import attaches
    # PullInfo, so the first one found identifies a pulled base.
    pull_info = None
    for manifest in manifests:
        if PullInfo in manifest:
            pull_info = manifest[PullInfo]
            break

    # Prepare template data for annotations
    templates = {}
    if ctx.attr.annotations:
        templates["annotations"] = ctx.attr.annotations

    # Prepare newline_delimited_lists_files if annotations_file is provided
    newline_delimited_lists_files = None
    if ctx.attr.annotations_file != None:
        annotations_file = ctx.file.annotations_file
        newline_delimited_lists_files = {"annotations": annotations_file}

    # Expand templates if needed (either from templates dict or from file)
    config_json = None
    if templates or newline_delimited_lists_files:
        config_json = expand_or_write(
            ctx = ctx,
            templates = templates,
            output_name = ctx.label.name + "_config_templates.json",
            only_if_stamping = True,
            newline_delimited_lists_files = newline_delimited_lists_files,
        )

    index_out = ctx.actions.declare_file(ctx.attr.name + "_index.json")
    descriptor_out = ctx.actions.declare_file(ctx.label.name + "_descriptor.json")
    digest_out = ctx.actions.declare_file(ctx.label.name + "_digest")

    # Resolve subject descriptor if provided
    subject_descriptor_file = None
    if ctx.attr.subject != None:
        if ImageManifestInfo in ctx.attr.subject:
            subject_descriptor_file = ctx.attr.subject[ImageManifestInfo].descriptor
        elif ImageIndexInfo in ctx.attr.subject:
            subject_info = ctx.attr.subject[ImageIndexInfo]
            subject_descriptor_file = subject_info.descriptor
        else:
            fail("subject must provide ImageManifestInfo or ImageIndexInfo")

    write_index_json(
        ctx,
        output = index_out,
        descriptor = descriptor_out,
        digest = digest_out,
        manifests = manifest_infos,
        config_json = config_json,
        subject_descriptor = subject_descriptor_file,
    )
    sparse_layout = _build_sparse_oci_layout(ctx, "directory", index_out, manifest_infos)
    index_info_provider = ImageIndexInfo(
        descriptor = descriptor_out,
        index = index_out,
        manifests = manifest_infos,
        sparse_oci_layout = sparse_layout,
    )
    providers = [
        DefaultInfo(files = depset([index_out])),
        index_info_provider,
    ]
    if pull_info != None:
        providers.append(pull_info)

    deploy_info, push_output_groups = process_deploy_specs(
        ctx,
        manifest_info = None,
        index_info = index_info_provider,
        manifest_infos = manifest_infos,
        pull_info = pull_info,
        push_specs = ctx.attr.push_specs,
        load_specs = ctx.attr.load_specs,
        allow_manifest_tags = True,
        sparse_layout = sparse_layout,
    )

    output_groups = dict(
        descriptor = depset([descriptor_out]),
        digest = depset([digest_out]),
        root_blob = depset([index_out]),
        oci_layout = depset([_build_oci_layout(ctx, "directory", index_out, manifest_infos)]),
        oci_tarball = depset([_build_oci_layout(ctx, "tar", index_out, manifest_infos)]),
        sparse_oci_layout = depset([sparse_layout]),
    )
    if deploy_info != None:
        providers.append(deploy_info)
        output_groups["deploy_manifest"] = depset([deploy_info.deploy_manifest])
    for group_name, files in push_output_groups.items():
        output_groups[group_name] = depset(files)
    providers.append(OutputGroupInfo(**output_groups))

    return providers

image_index = rule(
    implementation = _image_index_impl,
    doc = """Creates a multi-platform OCI image index from platform-specific manifests.

This rule combines multiple single-platform images (created by image_manifest) into
a multi-platform image index. The index allows container runtimes to automatically
select the appropriate image for their platform.

The rule supports two usage patterns:
1. Explicit manifests: Provide pre-built manifests for each platform
2. Platform transitions: Provide one manifest target and a list of platforms

The rule produces:
- OCI image index JSON file
- An optional OCI layout directory or tar (via output groups)
- ImageIndexInfo provider for use by image_push

Example (explicit manifests):

```python
image_index(
    name = "multiarch_app",
    manifests = [
        ":app_linux_amd64",
        ":app_linux_arm64",
        ":app_darwin_amd64",
    ],
)
```

Example (platform transitions):
```python
image_index(
    name = "multiarch_app",
    manifests = [":app"],
    platforms = [
        "//platform:linux-x86_64",
        "//platform:linux-aarch64",
    ],
)
```

Output groups:
- `digest`: Digest of the image (sha256:...)
- `root_blob`: The index JSON blob file
- `oci_layout`: Complete OCI layout directory with all platform blobs
- `oci_tarball`: OCI layout packaged as a tar file for downstream use
- `sparse_oci_layout`: Sparse OCI layout directory (without layer blobs, only layer descriptors)
""",
    attrs = {
        "manifests": attr.label_list(
            providers = [ImageManifestInfo],
            doc = "List of manifests for specific platforms.",
            cfg = multi_platform_image_transition,
        ),
        "platforms": attr.label_list(
            providers = [platform_common.PlatformInfo],
            doc = "(Optional) list of target platforms to build the manifest for. Uses a split transition. If specified, the 'manifests' attribute should contain exactly one manifest.",
        ),
        "subject": attr.label(
            doc = """Optional subject for the index.

Sets the `subject` field in the OCI index, which is a descriptor pointing to
another manifest or index. This is used for establishing referrer relationships,
such as attaching SBOMs, signatures, or attestations to an existing image.

The target must provide either ImageManifestInfo or ImageIndexInfo.
""",
            providers = [[ImageManifestInfo], [ImageIndexInfo]],
        ),
        "annotations": attr.string_dict(
            doc = """Arbitrary metadata for the image index.

Subject to [template expansion](/docs/templating.md).""",
        ),
        "annotations_file": attr.label(
            doc = """File containing annotations for the image index, as JSON or newline-delimited text.

The file is parsed in one of the following formats, auto-detected from its contents:

- JSON object with string values: `{"key": "value"}`
- JSON object with list values: `{"key": ["value1", "value2"]}` (the last value wins)
- JSON array of `KEY=VALUE` strings: `["key=value"]`
- newline-delimited `KEY=VALUE` text (one per line; blank lines and `#` comments are ignored)

Values in JSON objects are used verbatim, so they can encode arbitrary strings including
values that contain `=`, spaces, or newlines. The `KEY=VALUE` forms (JSON array and text)
split on the first `=` and trim surrounding whitespace from the key and value.

Annotations from this file are merged with annotations specified via the `annotations`
attribute. Values from the file take precedence over the `annotations` attribute for matching keys.

Example file content:
```
version=1.0.0
build.date=2024-01-15
source.url=https://github.com/...
```

Each annotation is subject to [template expansion](/docs/templating.md).
""",
            allow_single_file = True,
        ),
        "build_settings": attr.string_keyed_label_dict(
            providers = [BuildSettingInfo],
            doc = """Build settings for template expansion.

Maps template variable names to string_flag targets. These values can be used in
the annotations attribute using `{{.VARIABLE_NAME}}` syntax (Go template).

Example:
```python
build_settings = {
    "REGISTRY": "//settings:docker_registry",
    "VERSION": "//settings:app_version",
}
```

See [template expansion](/docs/templating.md) for more details.
""",
        ),
        "stamp": attr.string(
            default = "auto",
            values = ["auto", "force", "disabled"],
            doc = """Controls build stamping for template expansion.

- **`auto`** (default): Defers to the global `--@rules_img//img/settings:stamp` setting.
- **`force`**: Always stamp if templates contain `{{}}` placeholders, ignoring Bazel's `--stamp` flag.
- **`disabled`**: Never include stamp information.

See [template expansion](/docs/templating.md) for available stamp variables.
""",
        ),
        "_oci_layout_settings": attr.label(
            default = Label("//img/private/settings:oci_layout"),
            providers = [OCILayoutSettingsInfo],
        ),
        "_stamp_settings": attr.label(
            default = Label("//img/private/settings:stamp"),
            providers = [StampSettingInfo],
        ),
        "_push_settings": attr.label(
            default = Label("//img/private/settings:push"),
            providers = [PushSettingsInfo],
        ),
        "_load_settings": attr.label(
            default = Label("//img/private/settings:load"),
            providers = [LoadSettingsInfo],
        ),
        "push_specs": attr.label_list(
            doc = """Push configurations to produce DeployInfo for this image index.

Each entry should be an `image_push_spec` target (providing `PushConfigInfo`).
When set (together with or without `load_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.

For multi-platform pushes, `manifest_tags` on the push spec are expanded
per child manifest with platform variables (`{{.os}}`, `{{.architecture}}`, etc.).
""",
            providers = [PushConfigInfo],
        ),
        "load_specs": attr.label_list(
            doc = """Load configurations to produce DeployInfo for this image index.

Each entry should be an `image_load_spec` target (providing `LoadConfigInfo`).
When set (together with or without `push_specs`), this rule additionally returns
`DeployInfo`, making it directly usable as an operation in `multi_deploy`.
""",
            providers = [LoadConfigInfo],
        ),
    },
    toolchains = TOOLCHAINS,
    cfg = reset_platform_transition,
)
