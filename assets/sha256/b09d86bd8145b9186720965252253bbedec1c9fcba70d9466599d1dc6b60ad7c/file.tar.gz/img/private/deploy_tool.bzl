"""Rule used to create targets that have DeployToolInfo."""

load("//img/private/providers:deploy_tool_info.bzl", "DeployToolInfo")

def _img_deploy_tool_impl(ctx):
    executable = ctx.actions.declare_file(ctx.label.name)
    ctx.actions.symlink(output = executable, target_file = ctx.file.img_deploy_exe, is_executable = True)
    return [
        DefaultInfo(
            executable = executable,
            runfiles = ctx.runfiles(files = [executable]),
        ),
        DeployToolInfo(
            img_deploy_exe = ctx.file.img_deploy_exe,
            launcher_template = ctx.file.launcher_template,
        ),
        OutputGroupInfo(
            img_deploy_exe = depset([ctx.file.img_deploy_exe]),
            launcher_template = depset([ctx.file.launcher_template]),
        ),
    ]

img_deploy_tool = rule(
    implementation = _img_deploy_tool_impl,
    attrs = {
        "img_deploy_exe": attr.label(
            allow_single_file = True,
            mandatory = True,
        ),
        "launcher_template": attr.label(
            mandatory = True,
            allow_single_file = True,
        ),
    },
    doc = "Defines a set of tools used to deploy images.",
    executable = True,
    provides = [DeployToolInfo],
)
