"""rule to import OCI images from a local directory."""

load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("//img/private/common:build.bzl", "TOOLCHAIN")
load("//img/private/common:layer_helper.bzl", "build_layer_mtree", "image_mtree_or_none", "media_type_is_tar")
load("//img/private/common:layout_blob.bzl", "copy_blobs_to_output_base")
load("//img/private/common:sparse_oci_layout.bzl", "build_sparse_oci_layout_for_index", "build_sparse_oci_layout_for_manifest")
load("//img/private/providers:index_info.bzl", "ImageIndexInfo")
load("//img/private/providers:manifest_info.bzl", "ImageManifestInfo")
load("//img/private/providers:pull_info.bzl", "PullInfo")
load("//img/private/providers:single_layer_info.bzl", "SingleLayerInfo")
load(":manifest_media_type.bzl", "get_media_type")

def _digest_to_file(ctx, digest):
    """Get a starlark File object for a digest."""
    if not digest in ctx.attr.files:
        # this is a missing blob
        return None
    label = ctx.attr.files[digest]
    files = label[DefaultInfo].files.to_list()
    if len(files) != 1:
        fail("invalid number of files for digest: {}".format(digest))
    return files[0]

def _image_blobs(ctx):
    """Resolve every blob digest of the image to the files the rule hands out.

    A pulled image's blobs are source files of the repository that `image_pull`
    generated, and a source file lives outside the output base. Referencing one
    from inside a tree artifact (which is what the OCI layouts do, by relative
    symlink) therefore only works in the execroot of the build that created the
    tree. To keep the layouts self-contained, the source files are copied into
    the output base -- hardlinked, reflinked or, failing both, really copied.

    Manifests, indexes and configs are small, and the layouts always embed them,
    so they are always copied and the copy is what the providers carry. Layer
    blobs are large and most consumers (pushing, loading, mtree) read them
    directly, so they keep pointing at the source file and the copy is recorded
    as `SingleLayerInfo.generated_blob` on the side. A single action copies all
    of them, so it only ever runs for an image whose layout is actually built.

    Args:
        ctx: Rule context.

    Returns:
        struct with two digest-keyed dicts: `file`, the manifest, index, config
        or layer file to put in this rule's providers, and `generated_layer`,
        the output-base copy of a layer blob that is a source file.
    """
    files = {}
    generated_layers = {}
    metadata_pairs = []
    layer_pairs = []

    for digest in ctx.attr.files:
        source = _digest_to_file(ctx, digest)
        files[digest] = source
        if not source.is_source:
            continue
        copy = ctx.actions.declare_file("{}_blobs/{}".format(ctx.label.name, digest.replace("sha256:", "sha256/")))

        # Everything in `data` is a manifest, an index, or a config: the blobs
        # the repository rule inlined into the generated BUILD file.
        if digest in ctx.attr.data:
            files[digest] = copy
            metadata_pairs.append((source, copy))
        else:
            generated_layers[digest] = copy
            layer_pairs.append((source, copy))

    if len(metadata_pairs) > 0:
        copy_blobs_to_output_base(ctx, metadata_pairs, "CopyImageMetadataBlobs")
    if len(layer_pairs) > 0:
        copy_blobs_to_output_base(ctx, layer_pairs, "CopyImageLayerBlobs")

    return struct(file = files, generated_layer = generated_layers)

def _normalize_history_entry(entry):
    """Copy only the known OCI history fields.

    Imported image configs may contain non-standard keys in their history
    entries. The layer metadata JSON is later decoded by the manifest tool with
    DisallowUnknownFields (recursively), so forwarding unexpected keys would make
    the build fail. Keeping only the spec'd fields avoids that.
    See https://github.com/opencontainers/image-spec/blob/main/config.md#properties.
    """
    normalized = {}
    for field in ("created", "created_by", "author", "comment", "empty_layer"):
        if field in entry:
            normalized[field] = entry[field]
    return normalized

def _write_layer_info(ctx, blobs, manifest, config, history, layer_index, index_position = None):
    """Write layer info to file and return SingleLayerInfo provider."""
    layers = manifest.get("layers", [])
    if layer_index >= len(layers):
        fail("layer index out of range for manifest: {}".format(layer_index))
    layer = layers[layer_index]
    media_type = layer.get("mediaType", "unknown")
    digest = layer.get("digest", "unknown")
    if not digest.startswith("sha256:"):
        fail("invalid digest: {}".format(digest))
    size = layer.get("size", 0)
    if type(size) != type(0):
        fail("invalid size: {}".format(size))

    rootfs = config.get("rootfs", {})
    diff_ids = rootfs.get("diff_ids", [])

    # A config that declares no rootfs layers at all does not describe an image.
    # That is what an index's attestation children look like (buildx marks them
    # with the vnd.docker.reference.type annotation and an "unknown/unknown"
    # platform, and writes an empty config), and what a non-image OCI artifact
    # looks like. Such layers have no diff_id to record; they are still imported,
    # because the index blob is used verbatim and keeps referring to them.
    # A config that has *some* diff_ids but fewer than the manifest has layers is
    # a different matter -- that is a corrupt image, and still an error.
    diff_id = None
    if len(diff_ids) > 0:
        if layer_index >= len(diff_ids):
            fail("layer index out of range for config: {}".format(layer_index))
        diff_id = diff_ids[layer_index]
        if not diff_id.startswith("sha256:"):
            fail("invalid diff_id: {}".format(diff_id))

    if history and layer_index < len(history):
        layer_history = history[layer_index]
    else:
        layer_history = []
    metadata = dict(
        mediaType = media_type,
        digest = digest,
        size = size,
        annotations = layer.get("annotations", {}),
        history = layer_history,
    )
    if diff_id != None:
        metadata["diff_id"] = diff_id
    index_position_str = "" if index_position == None else str(index_position) + "_"
    layer_metadata = ctx.actions.declare_file(ctx.attr.name + "_{}{}_layer_metadata.json".format(index_position_str, layer_index))
    ctx.actions.write(layer_metadata, json.encode(metadata))

    blob = blobs.file.get(digest)

    # Record where this layer can be fetched from upstream. Every registry mirror
    # of this image's repository is a candidate source for the blob (the blob is
    # content-addressed by its own digest). This is attached to all imported
    # layers -- shallow and eager alike -- so a missing blob can later be fetched
    # from its original source at deploy time.
    sources = [
        struct(registry = registry, repository = ctx.attr.repository)
        for registry in ctx.attr.registries
    ]

    # Render an mtree from the layer blob whenever we actually have it (an eagerly
    # imported / pulled layer) and it is a tar. A shallow image whose layer blob is
    # missing can't be described, so its mtree stays None.
    mtree = None
    if blob != None and media_type_is_tar(media_type):
        mtree = build_layer_mtree(
            ctx,
            "{}_{}{}_layer".format(ctx.attr.name, index_position_str, layer_index),
            tar_blob = blob,
        )

    return SingleLayerInfo(
        blob = blob,
        generated_blob = blobs.generated_layer.get(digest),
        metadata = layer_metadata,
        media_type = media_type,
        estargz = layer.get("annotations", {}).get(TOC_JSON_DIGEST_ANNOTATION) != None,
        compact_stream = None,
        layer_input_files = None,
        layer_input_files_cas = None,
        sources = sources,
        mtree = mtree,
        ztoc = None,
    )

def _write_manifest_descriptor(ctx, digest, manifest, platform, descriptor = None, index_position = None):
    filename_suffix = "_descriptor.json" if index_position == None else "_{}_descriptor.json".format(index_position)
    out = ctx.actions.declare_file(ctx.attr.name + filename_suffix)
    if descriptor == None:
        # we don't have a prebuilt descriptor from an image index.
        # let's build our own.
        descriptor = dict(
            mediaType = get_media_type(manifest),
            size = len(ctx.attr.data[digest]),
            digest = digest,
            platform = platform,
        )
    ctx.actions.write(out, json.encode(descriptor))
    return out

def _build_manifest_info(ctx, blobs, digest, descriptor = None, index_position = None, platform = None):
    if not digest in ctx.attr.data:
        fail("missing blob for digest: " + digest)
    manifest = json.decode(ctx.attr.data[digest])
    media_type = get_media_type(manifest)
    if not media_type in [MEDIA_TYPE_MANIFEST, DOCKER_MANIFEST_V2]:
        fail("invalid mediaType in manifest: {}".format(media_type))
    config_digest = manifest.get("config", {}).get("digest", "missing config digest")
    if not config_digest in ctx.attr.data:
        fail("missing blob for config digest: " + config_digest)
    config = json.decode(ctx.attr.data[config_digest])

    # Extract platform information
    if platform == None:
        platform = dict(
            architecture = config.get("architecture", "unknown"),
            os = config.get("os", "unknown"),
            variant = config.get("variant", ""),
        )

    # Extract variant from platform dict
    variant = platform.get("variant", "")

    # ARM64 defaults to v8 variant
    # See: https://github.com/containerd/platforms/blob/2e51fd9435bd985e1753954b24f4b0453f4e4767/platforms.go#L290
    if platform.get("architecture") == "arm64" and variant == "":
        variant = "v8"

    layers = []

    # Assign each history entry to an actual non-empty layer. This preserves the full image
    # history across our layer splitting.
    history_by_layer = []
    current_layer = []
    for hist_entry in config.get("history", []):
        current_layer.append(_normalize_history_entry(hist_entry))
        if not hist_entry.get("empty_layer", False):
            history_by_layer.append(current_layer)
            current_layer = []

    # Bundle any trailing empty-layer entries with the last non-empty layer so they
    # aren't lost. If the history had no non-empty entries at all, attach them to the
    # first layer (when one exists) rather than dropping them.
    if current_layer:
        if history_by_layer:
            history_by_layer[-1].extend(current_layer)
        elif manifest.get("layers", []):
            history_by_layer.append(current_layer)
    for layer_index in range(len(manifest.get("layers", []))):
        layer_info = _write_layer_info(ctx, blobs, manifest, config, history_by_layer, layer_index, index_position)
        layers.append(layer_info)

    manifest_file = blobs.file.get(digest)
    config_file = blobs.file.get(config_digest)

    if index_position == None:
        sparse_layout = build_sparse_oci_layout_for_manifest(ctx, manifest_file, config_file, layers)
    else:
        sparse_layout = build_sparse_oci_layout_for_manifest(ctx, manifest_file, config_file, layers, suffix = "_" + str(index_position))

    # Use a per-manifest-unique base name so the merged mtree (and any on-the-fly
    # per-layer mtree) of one manifest in an index does not collide with another's.
    mtree_name = ctx.attr.name if index_position == None else "{}_{}".format(ctx.attr.name, index_position)

    return ImageManifestInfo(
        descriptor = _write_manifest_descriptor(ctx, digest, manifest, platform, descriptor, index_position),
        manifest = manifest_file,
        config = config_file,
        structured_config = config,
        architecture = platform.get("architecture", "unknown"),
        os = platform.get("os", "unknown"),
        variant = variant,
        layers = layers,
        mtree = image_mtree_or_none(ctx, mtree_name, layers),
        sparse_oci_layout = sparse_layout,
        soci_manifest = None,
        soci_config = None,
        soci_descriptor = None,
        soci_ztocs = [],
    )

def _image_import_impl(ctx):
    root_blob = json.decode(ctx.attr.data[ctx.attr.digest])
    media_type = get_media_type(root_blob)
    if not media_type in [MEDIA_TYPE_MANIFEST, DOCKER_MANIFEST_V2, MEDIA_TYPE_INDEX, DOCKER_MANIFEST_LIST_V2]:
        fail("invalid mediaType in root blob: {}".format(media_type))

    blobs = _image_blobs(ctx)

    providers = [
        DefaultInfo(files = depset([blobs.file.get(ctx.attr.digest)])),
        PullInfo(
            registries = ctx.attr.registries,
            repository = ctx.attr.repository,
            tag = ctx.attr.tag,
            digest = ctx.attr.digest,
        ),
    ]
    if media_type in [MEDIA_TYPE_MANIFEST, DOCKER_MANIFEST_V2]:
        # this is a single-platform manifest
        providers.append(_build_manifest_info(ctx, blobs, ctx.attr.digest))
    elif media_type in [MEDIA_TYPE_INDEX, DOCKER_MANIFEST_LIST_V2]:
        # this is a multi-platform index
        omitted = {digest: None for digest in ctx.attr.omitted_manifests}
        manifests = [
            _build_manifest_info(ctx, blobs, manifest["digest"], descriptor = manifest, index_position = position, platform = manifest.get("platform"))
            for (position, manifest) in enumerate(root_blob.get("manifests", []))
            if manifest["digest"] not in omitted
        ]
        index_descriptor_file = ctx.actions.declare_file(ctx.attr.name + "_index_descriptor.json")
        index_descriptor = dict(
            mediaType = media_type,
            size = len(ctx.attr.data[ctx.attr.digest]),
            digest = ctx.attr.digest,
        )
        ctx.actions.write(index_descriptor_file, json.encode(index_descriptor))
        index_file = blobs.file.get(ctx.attr.digest)
        sparse_layout = build_sparse_oci_layout_for_index(ctx, index_file, manifests)
        providers.append(ImageIndexInfo(
            descriptor = index_descriptor_file,
            index = index_file,
            manifests = manifests,
            sparse_oci_layout = sparse_layout,
        ))
    return providers

image_import = rule(
    implementation = _image_import_impl,
    attrs = {
        "digest": attr.string(),
        "data": attr.string_dict(),
        "files": attr.string_keyed_label_dict(
            allow_files = True,
        ),
        "omitted_manifests": attr.string_list(
            doc = """Digests of index children that were intentionally not fetched.

A platform-filtered pull downloads only some children of an image index, but stores the
index blob verbatim, so it keeps referring to all of them. Listing the skipped digests here
makes them be ignored; any other missing blob is still an error.""",
        ),
        "registries": attr.string_list(
            doc = "List of registry mirrors used to pull the image.",
        ),
        "repository": attr.string(
            doc = "Repository name of the image.",
        ),
        "tag": attr.string(
            doc = "Tag of the image.",
        ),
        "_mtree_path_prefix": attr.label(
            default = Label("//img/settings:mtree_path_prefix"),
            providers = [BuildSettingInfo],
        ),
        "_mtree_options": attr.label(
            default = Label("//img/settings:mtree_options"),
            providers = [BuildSettingInfo],
        ),
        "_mtree_layer_layout": attr.label(
            default = Label("//img/settings:mtree_layer_layout"),
            providers = [BuildSettingInfo],
        ),
        "_mtree_image_layout": attr.label(
            default = Label("//img/settings:mtree_image_layout"),
            providers = [BuildSettingInfo],
        ),
    },
    toolchains = [TOOLCHAIN],
)

MEDIA_TYPE_INDEX = "application/vnd.oci.image.index.v1+json"
DOCKER_MANIFEST_LIST_V2 = "application/vnd.docker.distribution.manifest.list.v2+json"
MEDIA_TYPE_MANIFEST = "application/vnd.oci.image.manifest.v1+json"
DOCKER_MANIFEST_V2 = "application/vnd.docker.distribution.manifest.v2+json"
MEDIA_TYPE_CONFIG = "application/vnd.oci.image.config.v1+json"
TOC_JSON_DIGEST_ANNOTATION = "containerd.io/snapshot/stargz/toc.digest"
STORE_UNCOMPRESSED_SIZE_ANNOTATION = "io.containers.estargz.uncompressed-size"
