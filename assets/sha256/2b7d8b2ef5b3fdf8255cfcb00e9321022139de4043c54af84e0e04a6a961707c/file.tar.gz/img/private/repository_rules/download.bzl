"""Repository rules for downloading container image components."""

load("@img_toolchain//:defs.bzl", "tool_for_repository_os")
load(":registry.bzl", "get_registries", "get_sources_list")

def _configured_attr(ctx, name):
    if hasattr(ctx, "attr") and hasattr(ctx.attr, name):
        value = getattr(ctx.attr, name)
        if value:
            return value
    return None

def _configured_env(ctx, name):
    if hasattr(ctx, "getenv"):
        value = ctx.getenv(name)
    else:
        value = ctx.os.environ.get(name)

    return value if value else None

def resolve_docker_config_path(ctx, docker_config_path = None, config = None):
    """Resolve the Docker-compatible auth config to a filesystem path.

    `docker_config_path` (a plain path) and `config` (a label) are mutually exclusive.

    Args:
        ctx: Repository or module context.
        docker_config_path: Optional path to a Docker-compatible auth config.
        config: Optional label of a Docker-compatible auth config file.

    Returns:
        The path to the auth config as a string, or None if neither is set.
    """
    if docker_config_path and config:
        fail("docker_config_path and config are mutually exclusive; set only one of them")
    if config:
        return str(ctx.path(config))
    return docker_config_path or None

def lazy_download_auth_attr(rctx, symlink_name = "docker_config.json"):
    """Return the auth attribute line for a generated `download_blobs` target.

    If the `config` label attribute is set, the file is symlinked into the repository
    so the build action can declare it as an input instead of depending on an
    absolute host path.

    Args:
        rctx: Repository context with `docker_config_path` and `config` attributes.
        symlink_name: Name of the symlink to create in the repository root.

    Returns:
        A string containing a single `download_blobs` attribute assignment.
    """
    resolve_docker_config_path(rctx, rctx.attr.docker_config_path, rctx.attr.config)
    if rctx.attr.config:
        rctx.symlink(rctx.attr.config, symlink_name)
        return "config = {},".format(repr(symlink_name))
    return "docker_config_path = {},".format(repr(rctx.attr.docker_config_path))

def auth_environment(ctx, credential_helper = None, docker_config_path = None):
    """Build auth-related environment overrides for repository/module executions.

    Args:
        ctx: Repository or module context.
        credential_helper: Optional credential helper path to pass as IMG_CREDENTIAL_HELPER.
        docker_config_path: Optional Docker-compatible auth config path to pass as REGISTRY_AUTH_FILE.

    Returns:
        Dictionary of environment variables to set on tool executions.
    """
    env = {}

    credential_helper = credential_helper or _configured_attr(ctx, "credential_helper") or _configured_env(ctx, "IMG_CREDENTIAL_HELPER")
    if credential_helper:
        env["IMG_CREDENTIAL_HELPER"] = credential_helper

    # Pulls are OCI registry operations, so honor the registry-scoped helper from
    # the environment. The img tool resolves IMG_CREDENTIAL_HELPER_OCI_REGISTRY
    # ahead of the generic IMG_CREDENTIAL_HELPER, so forwarding it lets it take
    # precedence for pulls as well.
    credential_helper_oci_registry = _configured_env(ctx, "IMG_CREDENTIAL_HELPER_OCI_REGISTRY")
    if credential_helper_oci_registry:
        env["IMG_CREDENTIAL_HELPER_OCI_REGISTRY"] = credential_helper_oci_registry

    docker_config_path = (
        docker_config_path or
        resolve_docker_config_path(ctx, _configured_attr(ctx, "docker_config_path"), _configured_attr(ctx, "config")) or
        _configured_env(ctx, "REGISTRY_AUTH_FILE")
    )
    if docker_config_path:
        env["REGISTRY_AUTH_FILE"] = docker_config_path

    docker_config = _configured_env(ctx, "DOCKER_CONFIG")
    if docker_config:
        env["DOCKER_CONFIG"] = docker_config

    return env

def execute_kwargs(ctx, timeout = None):
    """Build optional kwargs for `ctx.execute` invocations of the img tool.

    Only applies to img tool executions. Bazel's own downloader has no way to set a
    per-download timeout from a repository rule, so the timeout is silently ignored
    when the "bazel" downloader is used.

    Args:
        ctx: Repository or module context.
        timeout: Optional timeout in seconds. Falls back to the context's `timeout`
                 attribute. A falsy value (the default of `0`) means "don't pass a
                 timeout", leaving Bazel's own default in place.

    Returns:
        Dictionary of extra keyword arguments to pass to `ctx.execute`.
    """
    timeout = timeout or _configured_attr(ctx, "timeout")
    if not timeout:
        return {}
    return {"timeout": timeout}

_MANIFEST_ACCEPT_HEADERS = {
    "Accept": ",".join([
        "application/vnd.oci.image.index.v1+json",
        "application/vnd.docker.distribution.manifest.list.v2+json",
        "application/vnd.oci.image.manifest.v1+json",
        "application/vnd.docker.distribution.manifest.v2+json",
    ]),
}

def learn_digest_from_tag(rctx, *, tag, downloader, sources, credential_helper = None, docker_config_path = None, timeout = None):
    """Learn the digest of an image from its tag by downloading manifest headers.

    Args:
        rctx: Repository or module context.
        tag: The tag to resolve.
        downloader: "img_tool" or "bazel".
        sources: Sources dict mapping repositories to registries.
        credential_helper: Optional credential helper path, as in auth_environment.
        docker_config_path: Optional Docker-compatible auth config path, as in auth_environment.
        timeout: Optional timeout in seconds for the img tool, as in execute_kwargs.

    Returns:
        The resolved digest as a string (e.g., "sha256:abc123...") or None if resolution failed.
    """
    if downloader == "bazel":
        # Use Bazel's download to get the manifest and extract its digest
        # Build URLs from all sources
        urls = []
        for repository, registries in sources.items():
            for registry in registries:
                urls.append(
                    "https://{registry}/v2/{repository}/manifests/{tag}".format(
                        registry = registry,
                        repository = repository,
                        tag = tag,
                    ),
                )

        result = rctx.download(
            url = urls,
            output = "temp_manifest_for_digest_learning.json",
            headers = _MANIFEST_ACCEPT_HEADERS,
        )

        # The digest is the SHA256 of the downloaded manifest
        return "sha256:" + result.sha256
    else:
        # Use img_tool download-manifest command with --print-digest flag
        tool = tool_for_repository_os(rctx)
        tool_path = rctx.path(tool)

        # Convert sources dict to list format
        sources_list = get_sources_list(sources)

        args = [
            tool_path,
            "download-manifest",
            "--tag",
            tag,
            "--print-digest",
        ] + [
            "--source={}".format(source)
            for source in sources_list
        ]
        result = rctx.execute(
            args,
            environment = auth_environment(rctx, credential_helper = credential_helper, docker_config_path = docker_config_path),
            **execute_kwargs(rctx, timeout)
        )
        if result.return_code != 0:
            # Failed to get digest
            fail("Failed to learn digest from tag {}: {}".format(tag, result.stderr))

        # The digest is printed to stdout
        digest = result.stdout.strip()
        if len(digest) > 0 and digest.startswith("sha256:"):
            return digest
        fail("Failed to learn digest from tag {}: invalid digest output {}".format(tag, result.stdout))

def _check_existing_blob(rctx, digest, wait_and_read = True):
    """Check if a blob with the given digest already exists.

    Args:
        rctx: Repository context.
        digest: The blob digest to check.
        wait_and_read: If True, read the data from disk if the blob exists.

    Returns:
        A struct containing digest, path, and data of the downloaded blob or None if it does not exist.
    """
    if len(digest) < 64:
        # invalid digest
        return None
    blob_path = "blobs/sha256/" + digest.removeprefix("sha256:")
    if not rctx.path(blob_path).exists:
        return None
    return struct(
        digest = digest,
        path = blob_path,
        data = rctx.read(blob_path) if wait_and_read else None,
        waiter = None,
    )

def download_blob(rctx, *, downloader, digest, sources, wait_and_read = True, output = None, **kwargs):
    """Download a blob from a container registry using the specified downloader.

    Args:
        rctx: Repository context or module context.
        downloader: "img_tool" or "bazel".
        digest: The blob digest to download.
        sources: Sources dict mapping repositories to registries.
        wait_and_read: If True, wait for the download to complete and read the data.
                       If False, return a waiter that can be used to wait for the download.
        output: Optional output path for the downloaded blob. If not specified, defaults to "blobs/sha256/<sha256>".
        **kwargs: Additional arguments.

    Returns:
        A struct containing digest, path, and data of the downloaded blob.
    """
    sha256 = digest.removeprefix("sha256:")
    if output == None:
        output = "blobs/sha256/" + sha256

    # Only check for existing blob in default location if using default output path
    if output == "blobs/sha256/" + sha256:
        maybe_existing = _check_existing_blob(rctx, digest, wait_and_read)
        if maybe_existing != None:
            return maybe_existing
    if downloader == "bazel":
        # Build URLs from all sources
        urls = []
        for repository, registries in sources.items():
            for registry in registries:
                urls.append(
                    "{protocol}://{registry}/v2/{repository}/blobs/{digest}".format(
                        protocol = "https",
                        registry = registry,
                        repository = repository,
                        digest = digest,
                    ),
                )

        result = rctx.download(
            url = urls,
            sha256 = sha256,
            output = output,
            block = wait_and_read,
            **kwargs
        )
    elif downloader == "img_tool":
        tool = tool_for_repository_os(rctx)
        tool_path = rctx.path(tool)

        # Convert sources dict to list format
        sources_list = get_sources_list(sources)

        args = [
            tool_path,
            "download-blob",
            "--digest",
            digest,
            "--output",
            output,
        ] + [
            "--source={}".format(source)
            for source in sources_list
        ]
        result = rctx.execute(args, environment = auth_environment(rctx), **execute_kwargs(rctx))
        if result.return_code != 0:
            fail("Failed to download blob: {}{}".format(result.stdout, result.stderr))
    else:
        fail("unknown downloader: {}".format(downloader))

    return struct(
        digest = digest,
        path = output,
        data = rctx.read(output) if wait_and_read else None,
        waiter = result if downloader == "bazel" else None,
    )

def download_blob_from_sources(rctx, *, downloader, digest, wait_and_read = True, **kwargs):
    """Download a blob using the sources attribute from rctx.

    Args:
        rctx: Repository context with 'sources' attribute.
        downloader: "img_tool" or "bazel".
        digest: The blob digest to download.
        wait_and_read: If True, wait for the download to complete and read the data.
        **kwargs: Additional arguments passed to download_blob.

    Returns:
        A struct containing digest, path, and data of the downloaded blob.
    """
    return download_blob(
        rctx,
        downloader = downloader,
        digest = digest,
        sources = rctx.attr.sources,
        wait_and_read = wait_and_read,
        **kwargs
    )

def download_manifest_rctx(rctx, *, downloader, reference, **kwargs):
    """Download a manifest from a container registry (without support for multi-source).

    Args:
        rctx: Repository context with 'repository', 'registry', and 'registries' attributes.
        downloader: "img_tool" or "bazel".
        reference: The manifest reference to download.
        **kwargs: Additional arguments.

    Returns:
        A struct containing digest, path, and data of the downloaded manifest.
    """
    have_valid_digest = False
    registries = get_registries(rctx)
    if reference.startswith("sha256:"):
        have_valid_digest = True
        sha256 = reference.removeprefix("sha256:")
        kwargs["output"] = "blobs/sha256/" + sha256
    else:
        kwargs["output"] = "manifest.json"
        sha256 = None
    if have_valid_digest:
        maybe_existing = _check_existing_blob(rctx, reference)
        if maybe_existing != None:
            return maybe_existing

    # Build sources from legacy attrs
    sources = {rctx.attr.repository: registries}
    return download_manifest(
        rctx,
        downloader = downloader,
        reference = reference,
        sha256 = sha256,
        have_valid_digest = have_valid_digest,
        sources = sources,
        **kwargs
    )

def download_manifest_from_sources(rctx, *, downloader, reference, **kwargs):
    """Download a manifest using the sources attribute from rctx.

    Args:
        rctx: Repository context with 'sources' attribute.
        downloader: "img_tool" or "bazel".
        reference: The manifest reference to download (tag or digest).
        **kwargs: Additional arguments passed to download_manifest.

    Returns:
        A struct containing digest, path, and data of the downloaded manifest.
    """
    have_valid_digest = False
    if reference.startswith("sha256:"):
        have_valid_digest = True
        sha256 = reference.removeprefix("sha256:")
        kwargs["output"] = "blobs/sha256/" + sha256
    else:
        kwargs["output"] = "manifest.json"
        sha256 = None
    if have_valid_digest:
        maybe_existing = _check_existing_blob(rctx, reference)
        if maybe_existing != None:
            return maybe_existing
    return download_manifest(
        rctx,
        downloader = downloader,
        reference = reference,
        sha256 = sha256,
        have_valid_digest = have_valid_digest,
        sources = rctx.attr.sources,
        **kwargs
    )

def download_manifest(ctx, *, downloader, reference, sha256, have_valid_digest, sources, credential_helper = None, docker_config_path = None, timeout = None, **kwargs):
    """Download a manifest from a container registry using Bazel's downloader or img tool.

    Args:
        ctx: Repository context or module context.
        downloader: "img_tool" or "bazel".
        reference: The manifest reference to download.
        sha256: digest of the manifest (or None).
        have_valid_digest: bool indicating the presence of a valid digest.
        sources: Sources dict mapping repositories to registries.
        credential_helper: Optional credential helper path to pass to the img tool.
        docker_config_path: Optional Docker-compatible auth config path to pass to the img tool.
        timeout: Optional timeout in seconds for the img tool execution. Ignored by the
                 "bazel" downloader, which cannot be given a timeout from a repository rule.
        **kwargs: Additional arguments.

    Returns:
        A struct containing digest, path, and data of the downloaded manifest.
    """
    if downloader == "bazel":
        result = download_manifest_bazel(
            ctx,
            reference = reference,
            sha256 = sha256,
            have_valid_digest = have_valid_digest,
            sources = sources,
            **kwargs
        )
    else:
        # pull tool
        result = download_manifest_img_tool(
            ctx,
            reference = reference,
            sha256 = sha256,
            have_valid_digest = have_valid_digest,
            sources = sources,
            credential_helper = credential_helper,
            docker_config_path = docker_config_path,
            timeout = timeout,
        )

    if not have_valid_digest:
        # Get first repository from sources for error message
        repository = sources.keys()[0] if sources else "unknown"
        fail("""Missing valid image digest. Observed the following digest when pulling manifest for {}:
    sha256:{}""".format(
            repository,
            result.sha256,
        ))
    return result

def download_manifest_bazel(rctx, *, reference, sha256, have_valid_digest, sources, **kwargs):
    """Download a manifest from a container registry using Bazel's downloader.

    Args:
        rctx: Repository context.
        reference: The manifest reference to download.
        sha256: digest of the manifest (or None).
        have_valid_digest: bool indicating the presence of a valid digest.
        sources: Sources dict mapping repositories to registries.
        **kwargs: Additional arguments.

    Returns:
        A struct containing digest, path, and data of the downloaded manifest.
    """
    if have_valid_digest:
        kwargs["sha256"] = sha256
        kwargs["output"] = "blobs/sha256/" + sha256
    else:
        kwargs["output"] = "manifest.json"

    # Build URLs from all sources
    urls = []
    for repository, registries in sources.items():
        for registry in registries:
            urls.append(
                "{protocol}://{registry}/v2/{repository}/manifests/{reference}".format(
                    protocol = "https",
                    registry = registry,
                    repository = repository,
                    reference = reference,
                ),
            )

    manifest_result = rctx.download(
        url = urls,
        headers = _MANIFEST_ACCEPT_HEADERS,
        **kwargs
    )
    if have_valid_digest and manifest_result.sha256 != sha256:
        fail("expected manifest with digest sha256:{} but got sha256:{}".format(sha256, manifest_result.sha256))
    return struct(
        digest = reference if have_valid_digest else "sha256:" + manifest_result.sha256,
        path = kwargs["output"],
        data = rctx.read(kwargs["output"]),
        waiter = None,
    )

def download_manifest_img_tool(rctx, *, reference, sha256, have_valid_digest, sources, credential_helper = None, docker_config_path = None, timeout = None):
    """Download a manifest from a container registry using img tool.

    Args:
        rctx: Repository context.
        reference: The manifest reference to download.
        sha256: digest of the manifest (or None).
        have_valid_digest: bool indicating the presence of a valid digest.
        sources: Sources dict mapping repositories to registries.
        credential_helper: Optional credential helper path to pass to the img tool.
        docker_config_path: Optional Docker-compatible auth config path to pass to the img tool.
        timeout: Optional timeout in seconds for the img tool execution.

    Returns:
        A struct containing digest, path, and data of the downloaded manifest.
    """
    tool = tool_for_repository_os(rctx)
    tool_path = rctx.path(tool)
    destination = "manifest.json"
    if have_valid_digest:
        destination = "blobs/sha256/" + sha256

    # Convert sources dict to list format
    sources_list = get_sources_list(sources)

    args = [
        tool_path,
        "download-manifest",
        "--output",
        destination,
    ] + [
        "--source={}".format(source)
        for source in sources_list
    ]
    if have_valid_digest:
        args.extend(["--digest", "sha256:" + sha256])
    else:
        args.extend(["--tag", reference])

    result = rctx.execute(
        args,
        environment = auth_environment(
            rctx,
            credential_helper = credential_helper,
            docker_config_path = docker_config_path,
        ),
        **execute_kwargs(rctx, timeout)
    )
    if result.return_code != 0:
        fail("Failed to download manifest: {}".format(result.stderr))
    return struct(
        digest = reference if have_valid_digest else None,
        path = destination,
        data = rctx.read(destination),
        waiter = None,
    )

def download_layers(rctx, downloader, digests, sources):
    """Download all layers from a manifest.

    Args:
        rctx: Repository context.
        downloader: "img_tool" or "bazel".
        digests: A list of layer digests to download.
        sources: Sources dict mapping repositories to registries.

    Returns:
        A list of structs containing digest, path, and data of the downloaded layers.
    """
    downloaded_layers = []
    for digest in digests:
        layer_info = download_blob(rctx, downloader = downloader, digest = digest, sources = sources, wait_and_read = False)
        downloaded_layers.append(layer_info)
    for layer in downloaded_layers:
        if layer.waiter != None:
            layer.waiter.wait()
    return [downloaded_layer for downloaded_layer in downloaded_layers]

def download_with_tool(rctx, *, tool_path, reference, platforms = []):
    """Download an image using the img tool.

    Args:
        rctx: Repository context.
        tool_path: The path to the img tool to use for downloading.
        reference: The image reference to download.
        platforms: Optional list of "os/architecture[/variant]" strings. If non-empty, only
                   matching children of an image index are downloaded.

    Returns:
        A struct containing manifest and layers of the downloaded image.
    """
    registries = get_registries(rctx)
    args = [
        tool_path,
        "pull",
        "--reference=" + reference,
        "--repository=" + rctx.attr.repository,
        "--layer-handling=" + rctx.attr.layer_handling,
    ] + ["--registry=" + r for r in registries] + ["--platform=" + p for p in platforms]
    result = rctx.execute(args, environment = auth_environment(rctx), quiet = False, **execute_kwargs(rctx))
    if result.return_code != 0:
        fail("img tool failed with exit code {} and message {}".format(result.return_code, result.stderr))
