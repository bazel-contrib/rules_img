"""Reusable functions for creating tar-based container image layers."""

load("@bazel_skylib//lib:paths.bzl", "paths")
load("@bazel_skylib//rules:common_settings.bzl", "BuildSettingInfo")
load("//img/private/common:build.bzl", "TOOLCHAIN")
load("//img/private/common:layer_helper.bzl", "build_layer_mtree", "compression_tuning_args", "format_config_args", "layer_history_args", "resolve_format_config", "resolve_tar_format", "tar_format_args")
load("//img/private/common:media_types.bzl", "CPIO_GZIP_LAYER", "CPIO_LAYER", "CPIO_ZSTD_LAYER", "EROFS_LAYER", "EROFS_ZSTD_LAYER", "EXT4_LAYER", "FAT32_LAYER", "GZIP_LAYER", "ISO9660_LAYER", "UNCOMPRESSED_LAYER", "ZSTD_LAYER")
load("//img/private/providers:layers_info.bzl", "LayersInfo")
load("//img/private/providers:single_layer_info.bzl", "SingleLayerInfo")

# Parameter file directive lines bracketing entries whose metadata nothing
# depends on, such as the files of a runfiles tree. Between them, the img tool
# may hardlink a file to an earlier regular file in the layer with the same
# content even if their metadata differs; without such a file the entry is
# still written with its own metadata. Each is a line of its own (a path in the
# image is never empty, so a leading NUL marks a directive).
DEDUP_BY_CONTENT_START = "\0dedup=content"
DEDUP_BY_CONTENT_END = "\0dedup=exact"

def file_type(f):
    """Returns the tar entry type character for a file.

    Args:
        f: File object to determine the type of.

    Returns:
        A single character: 'f' for regular file, 'd' for directory, 'l' for symlink.
    """
    type = "f"  # regular file
    if f.is_directory:
        type = "d"
    if hasattr(f, "is_symlink") and f.is_symlink:
        type = "l"
    return type

def files_arg(f):
    type = file_type(f)
    return "{}{}".format(type, f.path)

def to_short_path_pair(f):
    type = file_type(f)
    if f.short_path.startswith("../"):
        return "{}\0{}{}".format(f.short_path[3:], type, f.path)
    return "_main/{}\0{}{}".format(f.short_path, type, f.path)

def empty_runfile_short_path(empty_filename):
    # runfiles.empty_filenames use the same convention as File.short_path:
    # external-repo entries start with "../<repo>/", main-repo entries are
    # repo-relative. Mirror to_short_path_pair so empty (e.g. __init__.py)
    # runfiles land in the same namespace as real runfiles: external repos keep
    # their name and main-repo files are anchored under _main/. Meant to be used
    # as an add_all(map_each=...) callback ahead of the runfiles-root format_each.
    if empty_filename.startswith("../"):
        return empty_filename[3:]
    return "_main/{}".format(empty_filename)

def root_symlinks_arg(x):
    type = file_type(x.target_file)
    return "{}\0{}{}".format(x.path, type, x.target_file.path)

def symlinks_arg(x):
    type = file_type(x.target_file)
    return "_main/{}\0{}{}".format(x.path, type, x.target_file.path)

def is_executable_target(default_info):
    """Returns True if a src should be treated as an executable with runfiles.

    `DefaultInfo.files_to_run.executable` alone is not a reliable signal: a
    `filegroup` holding exactly one file reports that file as its executable so
    that `bazel run` works on it, even though it is a plain file set. Treating
    such a target as an executable would place its single file at the srcs key
    verbatim, so a one-file filegroup would be laid out differently from the same
    filegroup with a second file added.

    A genuinely executable target has runfiles support, which a filegroup never
    creates. The runfiles manifest is the cheap signal for that, but it is not
    built under `--nobuild_runfile_manifests`; the repo mapping manifest covers
    that case under Bzlmod, and only if both are absent do we fall back to
    flattening the runfiles (a genuinely executable target always carries itself
    in its own runfiles, a filegroup has no default runfiles at all).

    Args:
        default_info: the DefaultInfo of the src.

    Returns:
        True if the src is an executable whose runfiles should be included.
    """
    files_to_run = default_info.files_to_run
    if files_to_run == None or files_to_run.executable == None:
        return False
    if files_to_run.executable.is_source:
        return False
    if files_to_run.runfiles_manifest != None or files_to_run.repo_mapping_manifest != None:
        return True
    default_runfiles = getattr(default_info, "default_runfiles", None)
    return default_runfiles != None and len(default_runfiles.files.to_list()) > 0

def _rebase_short_path(f):
    """Rebase a File's short_path into the unified runfiles-tree namespace.

    A File-typed convenience wrapper around empty_runfile_short_path: File
    short_paths and runfiles.empty_filenames share the same convention, so both
    rebase the same way (main-repo files under "_main/", external-repo files keep
    their repo name). Mirrors the layout to_short_path_pair produces for runfiles.
    """
    return empty_runfile_short_path(f.short_path)

def _place_files_header(mode, dest, anchor, skip, on_escape = "error"):
    """Build the header line for a --place-files parameter file.

    The header carries the per-target placement context that the Go tool needs
    to resolve each file's final path. It cannot be baked into the per-file
    lines because those are produced lazily by a map_each callback, which may
    not capture rule context. Fields are null-separated: mode, dest, anchor,
    skip, on_escape. See placement.go for the consuming side.
    """
    return "{}\0{}\0{}\0{}\0{}".format(mode, dest, anchor, skip, on_escape)

def place_extra_executable_files(ctx, files, exe, path_in_image, extra_args, extra_inputs):
    """Lazily place a target's default outputs other than the executable.

    Each file is placed at the same offset it has relative to the executable's
    directory, so that with the executable anchored at path_in_image, sidecar
    files keep their relative layout. The executable itself is skipped. Files
    above the executable's directory are allowed as long as they stay under the
    image root; the `extra_default_outputs` attribute decides what happens to
    the ones that are not: they are dropped silently ("best_effort", the
    default) or fail the build ("strict"). With "drop", nothing is placed at all
    and no parameter file is written.

    The depset is streamed via add_all(map_each=...) and never flattened in
    Starlark.

    Args:
        ctx: rule context.
        files: depset of File objects (the target's default outputs).
        exe: the executable File, anchored at path_in_image.
        path_in_image: normalized (no leading "/") tar path of the executable.
        extra_args: list to append the ctx.actions.args() object to.
        extra_inputs: list of depsets; `files` is appended so the outputs are
            available to the action.
    """
    policy = ctx.attr.extra_default_outputs
    if policy == "drop":
        # Nothing to place, but the executable is placed by the caller from this
        # same depset in some code paths, so it still has to reach the action.
        extra_inputs.append(depset([exe]))
        return
    args = ctx.actions.args()
    args.set_param_file_format("multiline")
    args.use_param_file("--place-files=%s", use_always = True)
    args.add(_place_files_header(
        "relative",
        paths.dirname(path_in_image),
        paths.dirname(_rebase_short_path(exe)),
        _rebase_short_path(exe),
        "error" if policy == "strict" else "skip",
    ))
    args.add_all(files, map_each = to_short_path_pair, expand_directories = False, uniquify = True)
    extra_args.append(args)
    extra_inputs.append(files)

def place_non_executable_files(ctx, files, label, path_in_image, layout, extra_args, extra_inputs):
    """Lazily place a non-executable target's default outputs.

    A single output is placed exactly at path_in_image. Multiple outputs treat
    path_in_image as a directory: "package_relative" preserves each file's path
    relative to the producing target's package, while "flatten" places each file
    directly in the directory by basename. A path_in_image ending in "/" is an
    explicit directory key, so the single-output shortcut does not apply to it
    and one output is laid out just like many. The single-output case is
    resolved by the Go tool, so the depset is never flattened in Starlark.

    Args:
        ctx: rule context.
        files: depset of File objects (the target's default outputs).
        label: the Label of the producing target (used as the package anchor).
        path_in_image: normalized (no leading "/") tar path.
        layout: "package_relative" or "flatten".
        extra_args: list to append the ctx.actions.args() object to.
        extra_inputs: list of depsets; `files` is appended so the outputs are
            available to the action.
    """
    pkg_anchor = "_main" if label.workspace_name == "" else label.workspace_name
    if label.package:
        pkg_anchor = "{}/{}".format(pkg_anchor, label.package)
    mode = "flatten" if layout == "flatten" else "package_relative"
    args = ctx.actions.args()
    args.set_param_file_format("multiline")
    args.use_param_file("--place-files=%s", use_always = True)
    args.add(_place_files_header(mode, path_in_image, pkg_anchor, ""))
    args.add_all(files, map_each = to_short_path_pair, expand_directories = False, uniquify = True)
    extra_args.append(args)
    extra_inputs.append(files)

def get_files_to_run_provider(src):
    """Retrieve FilesToRunProvider from a target.

    Args:
        src: target to get FilesToRunProvider from

    Returns:
        FilesToRunProvider or None: FilesToRunProvider if found in target
            provider, otherwise None
    """
    if not DefaultInfo in src:
        return None
    default_info = src[DefaultInfo]
    if not hasattr(default_info, "files_to_run"):
        return None
    return default_info.files_to_run

def get_repo_mapping_manifest(src):
    """Retrieve repo_mapping_manifest from a target if it exists.

    Args:
        src: target to get repo_mapping_manifest from

    Returns:
        File or None: repo_mapping_manifest
    """
    files_to_run_provider = get_files_to_run_provider(src)
    if files_to_run_provider:
        return getattr(files_to_run_provider, "repo_mapping_manifest")
    return None

def resolve_layer_settings(ctx):
    """Resolve layer settings from common attributes and build settings.

    Resolves 'auto' values for compression, layer_format, estargz, zstd_chunked,
    create_parent_directories, and tree_artifact_handling from global build
    settings. Computes derived values (media type and output file extension) and
    rejects combinations the layer formats do not support.

    With layer_format "ext4", "fat32", "iso9660" or "cpio", the options that only apply to tar layers
    (estargz, soci) are ignored and resolve to their disabled values. So is the
    compression, except for "cpio" (an initramfs is uncompressed unless asked
    otherwise). Compact layers apply as for every other format.

    Args:
        ctx: Rule context. Must have attrs from layer_attrs.common.

    Returns:
        struct with fields: compression, layer_format, tar_format, estargz,
        zstd_chunked, create_parent_directories, tree_artifact_handling,
        media_type, out_ext, format_config.
    """
    layer_format = ctx.attr.format
    if layer_format == "auto":
        layer_format = ctx.attr._default_layer_format[BuildSettingInfo].value
    is_erofs = layer_format == "erofs"
    is_ext4 = layer_format == "ext4"
    is_fat32 = layer_format == "fat32"
    is_iso9660 = layer_format == "iso9660"
    is_cpio = layer_format == "cpio"

    compression = ctx.attr.compress
    if compression == "auto":
        if is_erofs or is_cpio:
            # The global default (gzip) has no EROFS media type, so an EROFS
            # layer that did not ask for a compression is left uncompressed.
            # So is an initramfs, which the kernel unpacks as it is.
            compression = "none"
        else:
            compression = ctx.attr._default_compression[BuildSettingInfo].value
    if is_ext4 or is_fat32 or is_iso9660:
        # An ext4, FAT32 or ISO 9660 layer is a filesystem image the layer command writes directly,
        # so the options that only apply to tar layers resolve to their disabled
        # values instead of being rejected -- an explicit compress, estargz,
        # zstd_chunked or soci on such a layer is ignored, not an error. A cpio
        # layer does the same, except that its compression applies.
        compression = "none"

    tar_format = resolve_tar_format(ctx, compression, erofs = is_erofs, ext4 = is_ext4, fat32 = is_fat32, iso9660 = is_iso9660, cpio = is_cpio)

    soci = ctx.attr.soci
    if soci == "auto":
        soci = "disabled" if is_erofs or is_cpio else ctx.attr._default_soci[BuildSettingInfo].value
    soci_enabled = soci == "enabled" and not is_ext4 and not is_fat32 and not is_iso9660 and not is_cpio
    soci_span_size = ctx.attr._default_soci_span_size[BuildSettingInfo].value

    create_parent_directories = ctx.attr.create_parent_directories
    if create_parent_directories == "auto":
        create_parent_directories = ctx.attr._default_create_parent_directories[BuildSettingInfo].value
    create_parent_directories_enabled = create_parent_directories == "enabled"

    tar_end_of_archive = ctx.attr._tar_end_of_archive[BuildSettingInfo].value == "enabled" and layer_format == "tar"

    tree_artifact_handling = ctx.attr.tree_artifact_handling
    if tree_artifact_handling == "auto":
        tree_artifact_handling = ctx.attr._default_tree_artifact_handling[BuildSettingInfo].value

    format_config = resolve_format_config(ctx, layer_format)
    if is_ext4:
        out_ext = ".ext4"
        media_type = EXT4_LAYER
    elif is_fat32:
        out_ext = ".fat32"
        media_type = FAT32_LAYER
    elif is_iso9660:
        out_ext = ".iso"
        media_type = ISO9660_LAYER
    elif is_cpio:
        if compression == "gzip":
            out_ext = ".cpio.gz"
            media_type = CPIO_GZIP_LAYER
        elif compression == "zstd":
            out_ext = ".cpio.zst"
            media_type = CPIO_ZSTD_LAYER
        else:
            out_ext = ".cpio"
            media_type = CPIO_LAYER
    elif is_erofs:
        # An EROFS layer's blob is a filesystem image, so gzip has no media type
        # in the family, and the tar-specific lazy-pulling formats do not apply.
        if compression == "gzip":
            fail(("format = \"erofs\" cannot be gzip-compressed: there is no " +
                  "application/vnd.erofs.layer.v1+gzip media type. Set compress = \"none\" " +
                  "(the blob is then mountable as it is) or compress = \"zstd\"."))
        if soci_enabled:
            fail("soci indexes gzip tar layers and cannot be combined with format = \"erofs\".")

        if compression == "zstd":
            out_ext = ".erofs.zst"
            media_type = EROFS_ZSTD_LAYER
        else:
            out_ext = ".erofs"
            media_type = EROFS_LAYER
    elif compression == "gzip":
        out_ext = ".tgz"
        media_type = GZIP_LAYER
    elif compression == "zstd":
        out_ext = ".tar.zst"
        media_type = ZSTD_LAYER
    elif compression == "none":
        out_ext = ".tar"
        media_type = UNCOMPRESSED_LAYER
    else:
        fail("Unsupported compression: {}".format(compression))

    if ctx.attr.media_type:
        media_type = ctx.attr.media_type

    compact_layers = ctx.attr._experimental_compact_layers[BuildSettingInfo].value == "enabled"
    compact_layers_inline_threshold = ctx.attr._experimental_compact_layers_inline_threshold[BuildSettingInfo].value
    compact_layers_materialize_blob = ctx.attr._experimental_compact_layers_materialize_blob[BuildSettingInfo].value == "enabled"

    return struct(
        compression = compression,
        layer_format = layer_format,
        tar_format = tar_format,
        estargz = tar_format.estargz,
        zstd_chunked = tar_format.zstd_chunked,
        create_parent_directories = create_parent_directories_enabled,
        tar_end_of_archive = tar_end_of_archive,
        tree_artifact_handling = tree_artifact_handling,
        media_type = media_type,
        out_ext = out_ext,
        compact_layers = compact_layers,
        compact_layers_inline_threshold = compact_layers_inline_threshold,
        compact_layers_materialize_blob = compact_layers_materialize_blob,
        soci = soci_enabled,
        soci_span_size = soci_span_size,
        format_config = format_config,
    )

def create_single_layer(ctx, settings, name, extra_args = [], extra_inputs = []):
    """Create a single layer using 'img layer'.

    Lower-level variant of create_tar_layer that accepts an explicit output
    name and returns the layer components directly, allowing the caller to
    assemble providers from multiple layers.

    The layer's container format comes from `settings.layer_format`: a tar
    changeset, an EROFS filesystem image, an ext4, FAT32 or ISO 9660 filesystem
    image or a cpio archive. Everything else here -- the compact
    stream, the cas-dir of input files, the mtree, provider assembly -- is
    format-agnostic.

    Args:
        ctx: Rule context. Must have attrs from layer_attrs.common.
        settings: struct returned by resolve_layer_settings().
        name: Base name for output files (e.g. "app_layer_stdlib").
        extra_args: list of strings and/or ctx.actions.args() objects to insert
            between the base arguments and the output path.
        extra_inputs: list of depset objects to merge with base inputs.

    Returns:
        tuple of (SingleLayerInfo, out_file_or_None, metadata_file, compact_stream_file_or_None, mtree_file, ztoc_file_or_None).
    """
    is_erofs = settings.layer_format == "erofs"
    is_ext4 = settings.layer_format == "ext4"
    is_fat32 = settings.layer_format == "fat32"
    is_iso9660 = settings.layer_format == "iso9660"
    is_cpio = settings.layer_format == "cpio"
    metadata_out = ctx.actions.declare_file(name + "_metadata.json")
    out = None
    compact_stream_out = None
    layer_input_files_cas = None
    if settings.compact_layers:
        compact_stream_out = ctx.actions.declare_file(name + settings.out_ext + ".cstream")
    else:
        out = ctx.actions.declare_file(name + settings.out_ext)

    # Emit a ztoc for lazy pulling when SOCI is enabled for a materialized gzip
    # layer. Compact-stream layers have no materialized blob to index, so they
    # never emit a ztoc here (a manifest that needs one reconstructs it later).
    ztoc_out = None
    if settings.soci and settings.compression == "gzip" and out != None:
        ztoc_out = ctx.actions.declare_file(name + settings.out_ext + ".ztoc")

    args = ["layer"] + layer_history_args(ctx) + ["--metadata", metadata_out.path, "--format", settings.compression]
    args.extend(format_config_args(settings.layer_format, settings.format_config))
    if ctx.attr.media_type:
        args.extend(["--media-type", ctx.attr.media_type])
    args.extend(compression_tuning_args(ctx, settings.compression, settings.tar_format))
    args.extend(tar_format_args(settings.tar_format))
    if settings.create_parent_directories:
        args.append("--create-parent-directories")
    if settings.tar_end_of_archive:
        args.append("--tar-end-of-archive")
    args.extend(["--layer-tree-artifact-handling", settings.tree_artifact_handling])
    for key, value in ctx.attr.annotations.items():
        args.extend(["--annotation", "{}={}".format(key, value)])
    if ctx.file.annotations_file != None:
        args.extend(["--annotations-file", ctx.file.annotations_file.path])
    if compact_stream_out:
        args.extend(["--compact-stream", compact_stream_out.path])
        args.append("--compact-stream-only")

        # An EROFS layer decides inlining itself (--erofs-inline-threshold).
        if settings.compact_layers_inline_threshold > 0 and settings.layer_format != "erofs":
            args.extend(["--compact-stream-inline-threshold", str(settings.compact_layers_inline_threshold)])
    if ztoc_out:
        args.extend(["--ztoc", ztoc_out.path, "--ztoc-span-size", str(settings.soci_span_size)])

    args.extend(extra_args)
    if out:
        args.append(out.path)

    inputs = []
    if ctx.file.annotations_file != None:
        inputs.append(depset([ctx.file.annotations_file]))
    inputs.extend(extra_inputs)

    outputs = [metadata_out]
    if out:
        outputs.append(out)
    if compact_stream_out:
        outputs.append(compact_stream_out)
    if ztoc_out:
        outputs.append(ztoc_out)

    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    ctx.actions.run(
        outputs = outputs,
        inputs = depset(transitive = inputs),
        executable = img_toolchain_info.tool_exe,
        arguments = args,
        mnemonic = "LayerErofs" if is_erofs else ("LayerExt4" if is_ext4 else ("LayerFat32" if is_fat32 else ("LayerIso9660" if is_iso9660 else ("LayerCpio" if is_cpio else "LayerTar")))),
    )

    layer_input_files = depset(transitive = extra_inputs) if settings.compact_layers else None

    # In compact-stream mode, the layer blob is not materialized. Build a parallel,
    # content-addressed directory of the layer's input files so the tar can be
    # reconstructed from the index by resolving CAS references against it.
    if settings.compact_layers:
        layer_input_files_cas = _build_input_files_cas(ctx, name, extra_inputs)

    # Produce the mtree metadata description from whichever layer artifact exists.
    # For a tar layer the mtree comes from the headers alone, so the
    # compact-stream case needs no content; for an EROFS layer the metadata is
    # likewise carried inline, so the sparse image is enough. The same holds for
    # an ext4, a FAT32, an ISO 9660 and a cpio layer.
    if is_cpio:
        if out:
            mtree_out = build_layer_mtree(ctx, name, cpio_blob = out)
        else:
            mtree_out = build_layer_mtree(ctx, name, cpio_compact_stream = compact_stream_out)
    elif is_ext4:
        if out:
            mtree_out = build_layer_mtree(ctx, name, ext4_blob = out)
        else:
            mtree_out = build_layer_mtree(ctx, name, ext4_compact_stream = compact_stream_out)
    elif is_fat32:
        if out:
            mtree_out = build_layer_mtree(ctx, name, fat32_blob = out)
        else:
            mtree_out = build_layer_mtree(ctx, name, fat32_compact_stream = compact_stream_out)
    elif is_iso9660:
        if out:
            mtree_out = build_layer_mtree(ctx, name, iso9660_blob = out)
        else:
            mtree_out = build_layer_mtree(ctx, name, iso9660_compact_stream = compact_stream_out)
    elif is_erofs:
        if out:
            mtree_out = build_layer_mtree(ctx, name, erofs_blob = out)
        else:
            mtree_out = build_layer_mtree(ctx, name, erofs_compact_stream = compact_stream_out)
    elif out:
        mtree_out = build_layer_mtree(ctx, name, tar_blob = out)
    else:
        mtree_out = build_layer_mtree(ctx, name, compact_stream = compact_stream_out)

    # Optionally add a lazy action that reconstructs the real blob from the
    # compact stream, so SingleLayerInfo.blob is populated even in compact
    # mode. Bazel only runs this action if some requested target actually
    # consumes the resulting File (e.g. oci_layout). See docs/compact-stream.md.
    reconstructed_blob = None
    if settings.compact_layers and settings.compact_layers_materialize_blob:
        reconstructed_blob = ctx.actions.declare_file(name + settings.out_ext)
        ctx.actions.run(
            outputs = [reconstructed_blob],
            inputs = [compact_stream_out, layer_input_files_cas],
            executable = img_toolchain_info.tool_exe,
            arguments = [
                "compact-stream",
                "reconstruct",
                "--compact-stream",
                compact_stream_out.path,
                "--cas-dir",
                layer_input_files_cas.path,
                "--output",
                reconstructed_blob.path,
            ],
            mnemonic = "LayerReconstruct",
        )

    return (
        SingleLayerInfo(
            blob = out if out else reconstructed_blob,
            generated_blob = None,
            metadata = metadata_out,
            media_type = settings.media_type,
            estargz = settings.estargz,
            zstd_chunked = settings.zstd_chunked,
            compact_stream = compact_stream_out,
            layer_input_files = layer_input_files,
            layer_input_files_cas = layer_input_files_cas,
            sources = [],
            mtree = mtree_out,
            ztoc = ztoc_out,
        ),
        out,
        metadata_out,
        compact_stream_out,
        mtree_out,
        ztoc_out,
    )

def _input_file_cas_arg(f):
    """map_each for the cas-dir input file list.

    Returns an empty string for pure symlinks (which carry no content blob and
    are never referenced by the index); `args.add_all` skips empty strings. All
    other files (including expanded tree-artifact contents) are passed by path.
    Using map_each keeps the depset lazy (no analysis-time flattening).
    """
    if hasattr(f, "is_symlink") and f.is_symlink:
        return ""
    return f.path

def _build_input_files_cas(ctx, name, extra_inputs):
    """Build a content-addressed directory (sha256/<hex>) of layer input files.

    Runs `img cas-dir` over everything in `extra_inputs` (the files that make up
    the layer), expanding tree artifacts and skipping pure symlinks (which carry
    no content blob). The resulting tree artifact lets a layer be reconstructed
    from its compact stream without materializing the layer blob.

    Where the exec platform and Bazel version allow it, the entries are relative
    symlinks to the input files instead of copies, so a layer's inputs are not
    materialized twice.
    """
    output_dir = ctx.actions.declare_directory(name + ".inputfilecas")
    input_files = depset(transitive = extra_inputs)

    content_args = ctx.actions.args()
    content_args.set_param_file_format("multiline")
    content_args.use_param_file("--from-file=%s", use_always = True)
    content_args.add_all(input_files, map_each = _input_file_cas_arg, expand_directories = True)

    args = ctx.actions.args()
    args.add("cas-dir")
    args.add("--output", output_dir.path)

    img_toolchain_info = ctx.toolchains[TOOLCHAIN].imgtoolchaininfo
    if img_toolchain_info.use_treeartifact_uplevel_symlinks:
        args.add("--symlink")
    ctx.actions.run(
        outputs = [output_dir],
        inputs = input_files,
        executable = img_toolchain_info.tool_exe,
        arguments = [args, content_args],
        mnemonic = "LayerInputFilesCAS",
    )
    return output_dir

def create_tar_layer(ctx, settings, extra_args = [], extra_inputs = []):
    """Create a tar layer using 'img layer' and return providers.

    Declares output files, builds base arguments for the 'img layer' command,
    appends rule-specific extra_args, runs the action with mnemonic 'LayerTar',
    and returns a list of providers.

    Args:
        ctx: Rule context. Must have attrs from layer_attrs.common.
        settings: struct returned by resolve_layer_settings().
        extra_args: list of strings and/or ctx.actions.args() objects to insert
            between the base arguments and the output path.
        extra_inputs: list of depset objects to merge with base inputs.

    Returns:
        list of [DefaultInfo, OutputGroupInfo, LayersInfo].
    """
    layer_info, out, metadata_out, compact_stream_out, mtree_out, ztoc_out = create_single_layer(ctx, settings, ctx.attr.name, extra_args, extra_inputs)
    output_groups = dict(
        metadata = depset([metadata_out]),
        mtree = depset([mtree_out]),
    )
    if layer_info.blob:
        # Either the layer itself or, with compact layers and materialize_blob,
        # the lazily reconstructed blob.
        output_groups["layer"] = depset([layer_info.blob])
    if compact_stream_out:
        output_groups["experimental_compact_stream"] = depset([compact_stream_out])
    if ztoc_out:
        output_groups["ztoc"] = depset([ztoc_out])
    default_file = out if out else compact_stream_out
    return [
        DefaultInfo(files = depset([default_file])),
        OutputGroupInfo(**output_groups),
        LayersInfo(layers = [layer_info]),
    ]
